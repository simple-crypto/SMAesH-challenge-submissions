# -*- coding: utf-8 -*-
"""
Created on Mon May 15 09:14:50 2023

@author: martho
"""

import os
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Reshape , BatchNormalization , Dense , Concatenate, Softmax , Conv1D, AveragePooling1D, Flatten , Activation
from tensorflow.keras.optimizers import Adam
import tensorflow.experimental.numpy as tnp
import numpy as np

tnp.experimental_enable_numpy_behavior()
tf.keras.backend.set_floatx('float64')
seed = 7


tf.random.set_seed(seed)
np.random.seed(seed)
os.environ['PYTHONHASHSEED'] = str(seed)
os.environ['TF_DETERMINISTIC_OPS'] = '1'
os.environ['TF_CUDNN_DETERMINISTIC'] = '1'        


######################################
class SharedWeightsDenseLayer(tf.keras.layers.Layer):
    def __init__(self, input_dim=1,units = 1, shares = 16,name = '',activation = True,precision = 'float32'):
        if name == '':
            name = 'SharedWeightsDenseLayer_'+str(np.random.randint(0,high = 99999))
        super(SharedWeightsDenseLayer, self).__init__(name = name )
        self.w = self.add_weight(shape=(input_dim,units), dtype=precision,
                                  trainable=True,name = 'weights'+name,initializer=tf.keras.initializers.RandomUniform(seed=7)
                                  
        )
        self.b = self.add_weight(shape=(units,shares), dtype=precision,
                                  trainable=True,name = 'biais'+name,initializer=tf.keras.initializers.RandomUniform(seed=7)
                                  
        )
        self.input_dim = input_dim
        self.shares = shares
        self.activation = activation
        self.precision = tf.float64 if precision == 'float64' else tf.float32

    
        
    def call(self, inputs):
        x = tf.einsum('ijk, jf -> ifk',tf.cast(inputs,self.precision),self.w)    
        if self.activation:
            return tf.keras.activations.selu( x + self.b)
        else:
            return  x + self.b    
        


def get_hot_encode(label_set,classes = 256):    
    return tf.one_hot(label_set,depth = classes,dtype = tf.uint8)

### Multi-Task Models



def model_multi_task_sbox_input( learning_rate=0.001, classes=256 , name ='',summary = False):
    
    inputs_dict = {}
    
    traces  = Input(shape = (770,) ,name = 'traces')
    inputs_dict['traces'] =    traces
    traces = Reshape((70,11))(traces)
    traces = SharedWeightsDenseLayer(input_dim = traces.shape[1],units = 35,shares = traces.shape[-1],precision = 'float64')(traces)        
    traces = BatchNormalization(axis = 1)(traces)
        

    outputs = {} 
    map_kg = np.array([
              0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11
              ])     
    col_byte = 0
    input_to_output = []
    for branch in range(0,16,4):
            part = branch // 4
            concat = Concatenate(axis = 2)([traces[:,:,part:part +4],traces[:,:,part+6:part +8]])
            branch_block = dense_core_shared(Flatten()(concat),non_shared_block = 1,shared_block =  1, units = 8,branches = 4, output_units = 16,split = False,precision = 'float64')  
            branch_block = Concatenate(axis = 1)([branch_block[:,:,0],branch_block[:,:,1],branch_block[:,:,2],branch_block[:,:,3]])
            outputs['t_sig_{}'.format(branch//4)] = Activation('sigmoid',name = 'branch_{}'.format(branch//4))(branch_block)
            for pos in range(8):
                input_to_output.append(tf.expand_dims(branch_block[:,8 * pos : 8*(pos+1)],2))
    all_branches = Concatenate(axis = 2)(input_to_output)
    branch_output = dense_core_shared(all_branches,non_shared_block = 0, shared_block = 0,branches = 32,units = 256, output_units = 256,precision = 'float64')
    for byte in range(16):
        real_byte = map_kg[byte]
            
        outputs['t1_{}'.format(real_byte)] = Softmax(name = 'output_t1_{}'.format(real_byte),dtype = tf.float64)(branch_output[:,:,2*byte])

        outputs['t2_{}'.format(real_byte)] = Softmax(name = 'output_t2_{}'.format(real_byte),dtype = tf.float64)(branch_output[:,:,2*byte+1])  
            #outputs['x_{}'.format(byte)] = XorLayer(name = 'x_{}'.format(byte))([x1,x2])

            #outputs['x_{}'.format(byte)] = XorLayer(name = 'x_{}'.format(byte))([x1,x2])       
    losses = {}   
    metrics = {}
    for k , v in outputs.items():
        if not 'sig' in k:
            losses[k] = 'categorical_crossentropy'
            metrics[k] = 'accuracy'
        else:
            losses[k] = 'binary_crossentropy'
            metrics[k] = 'binary_accuracy'

    model = Model(inputs = inputs_dict,outputs = outputs,name='cnn_multi_task')
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(loss=losses, optimizer=optimizer, metrics=metrics)
    if summary:
        model.summary()
    return model   


def model_multi_task_sbox_output( learning_rate=0.001, classes=256 , name ='',summary = False):
    
    inputs_dict = {}
    
    traces  = Input(shape = (70*5,) ,name = 'traces')    
    inputs_dict['traces'] =    traces
    traces  = Reshape((70,5))(traces)
    traces = SharedWeightsDenseLayer(input_dim = traces.shape[1],units = 35,shares = traces.shape[-1],precision = 'float64')(traces)        
    traces = BatchNormalization(axis = 1)(traces)    

    outputs = {} 
    input_to_output = []
    for branch in range(0,16,2):
        part = branch // 4
        branch_block = dense_core_shared(Flatten()(traces[:,:,part:part+2]),non_shared_block =1,shared_block =  1, units = 8,branches = 2, output_units = 16,split = False,precision = 'float64' )
        branch_block = Concatenate(axis = 1)([branch_block[:,:,0],branch_block[:,:,1]])
        outputs['s_sig_{}'.format(branch//2)] = Activation('sigmoid',name = 'branch_{}'.format(branch//2))(branch_block)
        for pos in range(4):
            input_to_output.append(tf.expand_dims(branch_block[:,8 * pos : 8*(pos+1)],2))
    all_branches = Concatenate(axis = 2)(input_to_output)
    branch_output = dense_core_shared(all_branches,non_shared_block = 0, shared_block = 0,branches = 32,units = 256, output_units = 256,precision = 'float64')
    for byte in range(16):
        
            
        outputs['s1_{}'.format(byte)] = Softmax(name = 'output_s1_{}'.format(byte),dtype = tf.float64)(branch_output[:,:,2*byte])

        outputs['s2_{}'.format(byte)] = Softmax(name = 'output_s2_{}'.format(byte),dtype = tf.float64)(branch_output[:,:,2*byte+1])   
    losses = {}   
    metrics = {}
    for k , v in outputs.items():
        if not 'sig' in k:
            losses[k] = 'categorical_crossentropy'
            metrics[k] = 'accuracy'
        else:
            losses[k] = 'binary_crossentropy'
            metrics[k] = 'binary_accuracy'


    model = Model(inputs = inputs_dict,outputs = outputs,name='cnn_multi_task')
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(loss=losses, optimizer=optimizer, metrics=metrics)
    if summary:
        model.summary()
    return model   







######################## ARCHITECTURE BUILDING ################################

def cnn_core(inputs_core,convolution_blocks = 1 , kernel_size = [8],filters = 16, strides= 1  , pooling_size =2):
    x = inputs_core
    x  = tf.expand_dims(x , 2)
    for block in range(convolution_blocks):
        x = Conv1D(kernel_size=(kernel_size[block],), strides=strides, filters=filters, activation='selu', padding='same',kernel_initializer=tf.keras.initializers.RandomUniform(seed=7))(x)          
        x = BatchNormalization()(x)
        x = AveragePooling1D(pool_size = pooling_size)(x)
    
    output_layer = Flatten()(x) 

    return output_layer


def dense_core(inputs_core,dense_blocks,dense_units,activated = False):
    x = inputs_core
    
    for block in range(dense_blocks):
        x = Dense(dense_units, activation='selu')(x)        
        x = BatchNormalization()(x)
        
    if activated:
        output_layer = Dense(256,activation ='softmax' )(x)  
    else:
        output_layer = Dense(256)(x)   
    return output_layer    

def dense_core_shared(inputs_core, shared_block = 1,non_shared_block = 1, units = 64, branches = 16,output_units = 32,precision = 'float32',split = False):
    non_shared_branch = []
    if non_shared_block > 0:
        for branch in range(branches):
            x = inputs_core
            # for block in range(non_shared_block):
            x = Dense(units,activation ='selu',kernel_initializer=tf.keras.initializers.RandomUniform(seed=7))(x[:,:,branch] if split else x)
            # x = BatchNormalization()(x)
            non_shared_branch.append(tf.expand_dims(x,2))
        x = Concatenate(axis = 2)(non_shared_branch)
    else:
        x = inputs_core

    for block in range(shared_block):
        x = SharedWeightsDenseLayer(input_dim = x.shape[1],units = units,shares = branches)(x)        
        # x = BatchNormalization(axis = 1)(x)
    output_layer = SharedWeightsDenseLayer(input_dim = x.shape[1],units = output_units,activation = False,shares = branches,precision = precision)(x)   
    return output_layer 
