# SMAesH-challenge

Welcome to the SMAesH side-channel analysis challenge!

The documentation of the challenge is available on its [website](https://smaesh-challenge.simple-crypto.org).

## Contents

- `demo_submission`: A simple attack, as a starting point to improve
- `fpga_designs`: FPGA designs of the challenge
- `scripts`: Utility scripts to deal with challenge submissions
- `website`: The sources for the challenge website
