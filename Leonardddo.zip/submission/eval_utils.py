import key_guess
from dataset import DatasetReader
import msgpack
import msgpack_numpy
from scipy.stats import entropy
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt

msgpack_numpy.patch(allow_pickle=False)

MAX_SUCCESS_RANK = 2**68
MAX_SUBKEY_SIZE = 16

def load_kg(guess_path):
    with open(guess_path, 'rb') as f:
        kg = msgpack.load(f)
    return key_guess.KeyGuess.deserialize(kg)

def eval_attack(key_guess, attack_dataset_path):
    attack_dataset = DatasetReader.from_manifest(attack_dataset_path)
    assert key_guess.max_subkey_size() <= MAX_SUBKEY_SIZE
    key = [e['umsk_key'][0] for e in attack_dataset.iter_ntraces(1, fields=['umsk_key'])][0]
    #key2 = np.zeros(16, dtype = np.uint8)
    # print(key)
    ub = key_guess.key_rank_ub(np.unpackbits(key,bitorder='little').tolist())
    return ub

# t = [0]
# p = np.ones((128,2))/2
# tab = []
# for bit in range(4,11):
#     for i in range(bit):
#         p[i] = [0+0.05*i, 1-0.05*i]
#     key = [0] * 128
#     kg = key_guess.KeyGuess([[i] for i in range(128)], p)
#     for i in tqdm(np.arange(1,2**bit, dtype = np.uint8)):
#         a = format(i, f'0{bit}b')
#         for j in range(bit):
#             key[j] = int(a[-1-j])
#         ub = kg.key_rank_ub(key)
#         t.append(np.round(np.log2(ub), 1))
#
#     value,counts = np.unique(t, return_counts=True)
#     tab.append(entropy(counts, base=2))
# plt.plot(np.arange(4,11), tab)
# plt.title("Entropy VS #bits")
# plt.show()
# p[0] = [0, 1]
# p[1] = [0.1, 0.9]
# p[2] = [0.2, 0.8]
# p[3] = [0.3, 0.7]
# kg = key_guess.KeyGuess([[i] for i in range(128)], p)
# key = [0] * 128
# c = 0
# for i in range(2):
#     for j in range(2):
#         for k in range(2):
#             for l in range(2):
#                 if c:
#                     key[0] = i
#                     key[1] = j
#                     key[2] = k
#                     key[3] = l
#                     print(i,j,k)
#                     ub = kg.key_rank_ub(key)
#                     print(np.log2(ub))
#                 c = 1
