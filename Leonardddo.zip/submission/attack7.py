from dataclasses import dataclass
import json
import sys
import os
import pickle
from typing import List, Set, Dict, Type
import matplotlib.pyplot as plt
from dataset import DatasetReader
from key_guess import KeyGuess

#### Custom import
import numpy as np
from tap_config import TAP_CONFIG, TapConfig, TapSignal
import scalib.metrics
import scalib.modeling
import scalib.attacks
import aeshpc_32bit_d2_lib as plib
import tqdm
import msgpack
import msgpack_numpy
msgpack_numpy.patch(allow_pickle=False)
import eval_utils
import matplotlib.pyplot as plt
from tqdm.contrib import tmap
from tqdm.contrib.concurrent import process_map
from multiprocessing import Pool
#from termcolor import colored
from sasca_utils import NAMES
from concurrent.futures import ThreadPoolExecutor
# from sasca_utils import GRAPH, NAMES
#from create_graph_dist import GRAPH, NAMES
import copy
from sasca_utils import SBOX
print(NAMES)
# Maximum amount of a chunk. The dataset is read by 
# small part depicted as 'chunks', and this parameter set 
# the maximum size of each chunk. 
MAX_CHUNK_SIZE=int(2**10)
# Amount of traces used for the SNR computation (POIs identification) 
NT_PROF_SNR = None
# Amount of traces used for the creation of the templates.
NT_PROF_LDA = None
# Apply a centering process on each traces (in order to reduce any DC levels)
centered = True

global run_ttest
def run_ttest(tab):
    ttest, traces, labels = tab[0], tab[1], tab[2]
    ttest.fit_u(traces, labels)
    return ttest

def remove_lines(big_string, pat):
    # Split the big string into lines
    lines = big_string.split('\n')
    # Define the patterns to search for
    patterns = [f" {pat} ", f" {pat}_0 ", f" {pat}_1 ", f" lut_{pat} "]
    end_patterns = [f" {pat}", f" {pat}_0", " {pat}_1" f" lut_{pat}"]
    # Filter out the lines that contain any of the patterns or end with any of the end patterns
    lines = [line for line in lines if not any(pattern in line for pattern in patterns) and not any(line.endswith(end_pattern) for end_pattern in end_patterns)]
    # Join the lines back into a string
    big_string = '\n'.join(lines)
    return big_string

def union(lst1, lst2):
    final_list = list(set(lst1) | set(lst2))
    return final_list

def parta(t):
        map2 = [0,5,10,15,4,9,14,3,8,13,2,7,12,1,6,11]
        with open(os.path.join('.', 'profiling_s6_f.pkl'), 'rb') as f:
                profiled_model = pickle.load(f)
        lda_mod_SB = profiled_model["lda_obj_SB"]   
        # Create the factor graph that will be used. 
        #graph = scalib.attacks.FactorGraph(sasca_utils.SASCA_GRAPH_D2_Y, {"sbox":sasca_utils.SBOX})
        with open('gn4_2.pickle', 'rb') as file:
            gn = pickle.load(file)
        g = gn[0]
        names = gn[1]
        gr = [scalib.attacks.FactorGraph(i) for i in g]

        # Amount of traces to keep track of the amount of traces used during the attack.       
        cnt_traces = 0
        cnt_traces_used = 0
        iterobj = t

        # Amount of traces to be processed
        nchunks = len(iterobj)

        # Allocate memory to store the likelihood of obtain for each
        # byte of the key and for each chunks.
        like = np.ones([nchunks,16,256])/256
        idx_good = []
        with open('lut.pickle', 'rb') as file:
            luts = pickle.load(file)
        lp = np.zeros((16, 256))
        key = np.array([200,  30,  77, 124, 100, 9, 163, 92, 133, 124,  56, 162,  99,  18,  51,  47], dtype = np.uint8)
        #nsmall = len(iterobj // 96)
        #T = []
        #for i in range(96):
        #    T.append(attack_dataset.iter_ntraces(None, max_ntraces = nsmall, strat_trace =i *nsmall, max_chunk_size=MAX_CHUNK_SIZE
        for cidx,chunk in tqdm.tqdm(enumerate(iterobj),total=len(iterobj)):
            if cidx == 61132:
                break
            # Update counter
            cnt_traces += chunk['traces'].shape[0]
            if cnt_traces < -1:
                continue
            # Counter traces if required. 
            if not(centered):
                utraces = chunk["traces"]
            else:
                utraces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)
                utraces = np.square(utraces)

            # Recover the probability given the leakages values  
            probas_SB = np.array(list(lda_mod_SB.predict_proba(utraces)))
            #print(np.array(probas_SB).shape)
            c = 0
            for name in NAMES:
                for i in range(4):
                    for g in range(4):
                        if name+f'_{i}' in names[g]:
                # Get tap signal ID use for profiling of the share
                            A = luts[name][0].astype(dtype=bool)
                            P = chunk["umsk_plaintext"]
                            n = chunk['traces'].shape[0]
                            A = np.tile(A, (n, 1))
                            #print(A.shape)
                            #if i != 3:
                            #    D = luts[name][0][P[:, self.map2[(i+1)*4+g]] ^ key[self.map2[(i+1)*4+g]]]
                            #    if i ==0:
                            #        D = D ^ 1
                            #    for l in range(n):
                            #        A[l] = A[l] ^ D[l]
                            if i == 3:
                                C = np.where(A, probas_SB[c, :, 1][:, None], probas_SB[c, :, 0][:, None])
                                for l in range(n):
                                    C[l] = np.log(C[l][np.arange(256) ^ P[l, map2[i*4+g]]])
                                lp[map2[4*i +g]] += np.sum(C, axis = 0)
                            c += 1
        return lp

def partb(A):
        t = A[0]
        keyg = A[1]
        map2 = [0,5,10,15,4,9,14,3,8,13,2,7,12,1,6,11]
        with open(os.path.join('.', 'profiling_s6_f.pkl'), 'rb') as f:
                profiled_model = pickle.load(f)
        lda_mod_SB = profiled_model["lda_obj_SB"]   
        # Create the factor graph that will be used. 
        #graph = scalib.attacks.FactorGraph(sasca_utils.SASCA_GRAPH_D2_Y, {"sbox":sasca_utils.SBOX})
        with open('gn4_2.pickle', 'rb') as file:
            gn = pickle.load(file)
        g = gn[0]
        names = gn[1]
        gr = [scalib.attacks.FactorGraph(i) for i in g]

        # Amount of traces to keep track of the amount of traces used during the attack.       
        cnt_traces = 0
        cnt_traces_used = 0
        iterobj = t

        # Amount of traces to be processed
        nchunks = len(iterobj)

        # Allocate memory to store the likelihood of obtain for each
        # byte of the key and for each chunks.
        like = np.ones([nchunks,16,256])/256
        idx_good = []
        with open('lut.pickle', 'rb') as file:
            luts = pickle.load(file)
        lp = np.zeros((16, 256))
        key = np.array([200,  30,  77, 124, 100, 9, 163, 92, 133, 124,  56, 162,  99,  18,  51,  47], dtype = np.uint8)
        #nsmall = len(iterobj // 96)
        #T = []
        #for i in range(96):
        #    T.append(attack_dataset.iter_ntraces(None, max_ntraces = nsmall, strat_trace =i *nsmall, max_chunk_size=MAX_CHUNK_SIZE
        for cidx,chunk in tqdm.tqdm(enumerate(iterobj),total=len(iterobj)):
            if cidx == 61132:
                break
            # Update counter
            cnt_traces += chunk['traces'].shape[0]
            if cnt_traces < -1:
                continue
            # Counter traces if required. 
            if not(centered):
                utraces = chunk["traces"]
            else:
                utraces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)
                utraces = np.square(utraces)

            # Recover the probability given the leakages values  
            probas_SB = np.array(list(lda_mod_SB.predict_proba(utraces)))
            #print(np.array(probas_SB).shape)
            c = 0
            for name in NAMES:
                for i in range(4):
                    for g in range(4):
                        if name+f'_{i}' in names[g]:
                # Get tap signal ID use for profiling of the share
                            A = luts[name][0].astype(dtype=bool)
                            P = chunk["umsk_plaintext"]
                            n = chunk['traces'].shape[0]
                            A = np.tile(A, (n, 1))
                            #print(A.shape)
                            if i != 3:
                                D = luts[name][0][P[:, map2[(i+1)*4+g]] ^ keyg[map2[(i+1)*4+g]]]
                                if i ==0:
                                    D = D ^ 1
                                for l in range(n):
                                    A[l] = A[l] ^ D[l]
                            if i == 2:
                                C = np.where(A, probas_SB[c, :, 1][:, None], probas_SB[c, :, 0][:, None])
                                for l in range(n):
                                    C[l] = np.log(C[l][np.arange(256) ^ P[l, map2[i*4+g]]])
                                lp[map2[4*i +g]] += np.sum(C, axis = 0)
                            c += 1
        return lp

def partc(A):
        t = A[0]
        keyg = A[1]
        map2 = [0,5,10,15,4,9,14,3,8,13,2,7,12,1,6,11]
        with open(os.path.join('.', 'profiling_s6_f.pkl'), 'rb') as f:
                profiled_model = pickle.load(f)
        lda_mod_SB = profiled_model["lda_obj_SB"]   
        # Create the factor graph that will be used. 
        #graph = scalib.attacks.FactorGraph(sasca_utils.SASCA_GRAPH_D2_Y, {"sbox":sasca_utils.SBOX})
        with open('gn4_2.pickle', 'rb') as file:
            gn = pickle.load(file)
        g = gn[0]
        names = gn[1]
        gr = [scalib.attacks.FactorGraph(i) for i in g]

        # Amount of traces to keep track of the amount of traces used during the attack.       
        cnt_traces = 0
        cnt_traces_used = 0
        iterobj = t

        # Amount of traces to be processed
        nchunks = len(iterobj)

        # Allocate memory to store the likelihood of obtain for each
        # byte of the key and for each chunks.
        like = np.ones([nchunks,16,256])/256
        idx_good = []
        with open('lut.pickle', 'rb') as file:
            luts = pickle.load(file)
        lp = np.zeros((16, 256))
        key = np.array([200,  30,  77, 124, 100, 9, 163, 92, 133, 124,  56, 162,  99,  18,  51,  47], dtype = np.uint8)
        #nsmall = len(iterobj // 96)
        #T = []
        #for i in range(96):
        #    T.append(attack_dataset.iter_ntraces(None, max_ntraces = nsmall, strat_trace =i *nsmall, max_chunk_size=MAX_CHUNK_SIZE
        for cidx,chunk in tqdm.tqdm(enumerate(iterobj),total=len(iterobj)):
            if cidx == 61132:
                break
            # Update counter
            cnt_traces += chunk['traces'].shape[0]
            if cnt_traces < -1:
                continue
            # Counter traces if required. 
            if not(centered):
                utraces = chunk["traces"]
            else:
                utraces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)
                utraces = np.square(utraces)

            # Recover the probability given the leakages values  
            probas_SB = np.array(list(lda_mod_SB.predict_proba(utraces)))
            #print(np.array(probas_SB).shape)
            c = 0
            for name in NAMES:
                for i in range(4):
                    for g in range(4):
                        if name+f'_{i}' in names[g]:
                # Get tap signal ID use for profiling of the share
                            A = luts[name][0].astype(dtype=bool)
                            P = chunk["umsk_plaintext"]
                            n = chunk['traces'].shape[0]
                            A = np.tile(A, (n, 1))
                            #print(A.shape)
                            if i != 3:
                                D = luts[name][0][P[:, map2[(i+1)*4+g]] ^ keyg[map2[(i+1)*4+g]]]
                                if i ==0:
                                    D = D ^ 1
                                for l in range(n):
                                    A[l] = A[l] ^ D[l]
                            if i == 1:
                                C = np.where(A, probas_SB[c, :, 1][:, None], probas_SB[c, :, 0][:, None])
                                for l in range(n):
                                    C[l] = np.log(C[l][np.arange(256) ^ P[l, map2[i*4+g]]])
                                lp[map2[4*i +g]] += np.sum(C, axis = 0)
                            c += 1
        return lp



class Attack:
    """Implementation of the proposed attack.

    The sequence of method calls shall be the following during submission test:
    - for profiling: __init__ -> profile -> save_profile
    - for attack: __init__ -> load_profile -> attack

    The __main__ of this script can perform both profiling and evaluation at
    once, avoiding the need for on-disk data storage:
    __init__ -> profile -> attack -> attack -> ...
    """
    def __init__(self, attack_case: str):
        if attack_case not in ('A7_d2','S6_d2'):
            raise NotImplemented('attack case not implemented')
        self.attack_case = attack_case
        # To be completed.
        # Map to map the location of the sbox input to the ouput sbox
        self.map_in2out_SB = [0,13,10,7,4,1,14,11,8,5,2,15,12,9,6,3]
        self.map2 = [0,5,10,15,4,9,14,3,8,13,2,7,12,1,6,11]
    def profile(self, profile_datasets: List[DatasetReader]):
        # To be completed.
        # Run here the profiling, and store the result in attributes of self.
        # `profile_datasets` contains all the profiling datastets.
        #
        # Short intro on DatasetReader (see dataset.py for more details):
        # you can iterate on a DatasetReader, which iterates over parts of the
        # dataset (this is linked to the dataset being sharded in multiple
        # files).
        # Each iterm of the iterator is a Dict[str, np.ndarray], and the keys
        # are the fields of the dataset ('traces', 'seed', 'umsk_plaintext', ...).
        # The values are numpy arrays, whose first dimension is the multiple
        # traces in the chunk, and the remaining dimentions are field-specific
        # (e.g. for trace it is the lenght of the trace, for key and plaintext
        # it is 16).
        # If you want to use only a part of a dataset, see the method
        # DatasetReader.iter_ntraces(max_ntraces=..., start_trace=...)

        # As required, we end the function by setting the value of the variable 'self.profiled_model'.
        #with open(os.path.join(profile_dir, 'profiling_s6_f.pkl'), 'rb') as f:
        #    self.profiled_model = pickle.load(f)
        #self.profiled_model = self.profile_sasca(profile_datasets)
        pass

    def attack(self, attack_dataset: DatasetReader) -> KeyGuess:
        # To be completed.
        # attack_dataset is a DatasetReader (see comments in `profile`) with a
        # reduced set of fields (only trace and plaintext).
        # Return a KeyGuess (see key_guess.py)
        
        # Here, it is assumed that load_profile has been executed and that
        # the model can be accessed at self.profiled_model.
        return self.attack_sasca(attack_dataset)

    # DO NOT MODIFY! 
    def save_profile(self, profile_dir: str):
        # Save the result of profiling. You can write any file in the directory
        # `profile_dir`.
        # You can use any file format.
        return
        with open(os.path.join(profile_dir, 'profiling_s6_f.pkl'), 'wb') as f:
            pickle.dump(self.profiled_model,f)

    # DO NOT MODIFY! 
    def load_profile(self, profile_dir: str):
        # import time
        # time.sleep(25*60)
        # Load the result of profiling, as saved by `save_profile`.
        return
        with open(os.path.join(profile_dir, 'profiling_s6_f.pkl'), 'rb') as f:
            self.profiled_model = pickle.load(f)

    # From a byte id, return the location in the matrix representation of the
    # state. The location is representation as a pair of indexes, one for the
    # row, and one for the column. 
    def id2loc(self,bid):
        colid = bid // 4
        rowid = bid % 4
        return (rowid,colid)

    # Return the sharing part of the TapSignal instance (see TapSignal definition in tap_config.py for more details).
    def strshi(self, shi):
        return 'r' if shi == None else shi

    # Return the string id of a single byte of the state after the Sboxes. In
    # particular, bidx is the index of the byte (in [0,15]) and shi is the
    # index of the share (in [0,1]).
    def tapname_byte_fromSB(self, bidx,shi, round_id=0):
        # Fetch byte location for bidx
        (rid, cid) = self.id2loc(bidx) 
        # Clock index
        # Here:
        # - the +1 is used to take into account the first cycle of the execution, during 
        # which the KeySchedule of the first round starts. 
        # - the +6 is used to take into account the Sbox latency.  
        c2t = cid + 1 + 6 + 10*round_id
        # Return the indentifier. 
        tapsig_yi = "B_fromSB__{}.{}.{}.0:7.raw".format(rid,c2t,self.strshi(shi))
        return tapsig_yi

    # This function is the practical profiling method of the example package. 
    def profile_sasca(self, profile_datasets: List[DatasetReader]):
        return

    # This function is the practical implementation of the attack of the example submission package.
    def attack_sasca(self, attack_dataset: DatasetReader) -> KeyGuess:
        ntr = 10000000
        # Recover the LDAs objects from the model.
        #lda_mod_SB = self.profiled_model["lda_obj_SB"]   

        # Create the factor graph that will be used. 
        #graph = scalib.attacks.FactorGraph(sasca_utils.SASCA_GRAPH_D2_Y, {"sbox":sasca_utils.SBOX})
        with open('gn4_2.pickle', 'rb') as file:
            gn = pickle.load(file)
        g = gn[0]
        names = gn[1]
        gr = [scalib.attacks.FactorGraph(i) for i in g]

        # Amount of traces to keep track of the amount of traces used during the attack.       
        cnt_traces = 0
        cnt_traces_used = 0
        iterobj = attack_dataset.iter_ntraces(None, max_chunk_size=MAX_CHUNK_SIZE)

        # Amount of traces to be processed
        nchunks = len(iterobj)

        # Allocate memory to store the likelihood of obtain for each
        # byte of the key and for each chunks.
        like = np.ones([nchunks,16,256])/256
        idx_good = []
        with open('lut.pickle', 'rb') as file:
            luts = pickle.load(file)
        lp = np.zeros((16, 256))
        key = np.array([200,  30,  77, 124, 100, 9, 163, 92, 133, 124,  56, 162,  99,  18,  51,  47], dtype = np.uint8)
        nsmall = ntr // 96
        print(nsmall)
        T = []
        for i in range(96):
            T.append(attack_dataset.iter_ntraces(max_ntraces = nsmall, start_trace =i *nsmall, max_chunk_size=MAX_CHUNK_SIZE))
        LPS = process_map(parta, T, max_workers = 96)
        lp += np.sum(LPS, axis = 0)
        keyg = np.argmax(lp, axis = 1)
        T2 = []
        for i in T:
             T2.append([i, keyg])
        LPS = process_map(partb, T2, max_workers = 96)
        lp += np.sum(LPS, axis = 0)
        keyg = np.argmax(lp, axis = 1)
        T2 = []
        for i in T:
             T2.append([i, keyg])
        LPS = process_map(partc, T2, max_workers = 96)
        lp += np.sum(LPS, axis = 0)
        sum_log_like = lp
        kg = KeyGuess(
                [list(range(8*i,8*(i+1))) for i in range(16)],
                (-sum_log_like).tolist()
                )

        # As required, return the KeyGuess object
        return kg






# Import the SASCA graph.
        #from sasca_utils import SBOX
        #with open(os.path.join('.', 'profiling_s6_f.pkl'), 'rb') as f:
        #    self.profiled_model = pickle.load(f)

        # Recover the LDAs objects from the model.
        #lda_mod_SB = self.profiled_model["lda_obj_SB"]   

        # Create the factor graph that will be used. 
        #graph = scalib.attacks.FactorGraph(sasca_utils.SASCA_GRAPH_D2_Y, {"sbox":sasca_utils.SBOX})
        with open('gn4_2.pickle', 'rb') as file:
            gn = pickle.load(file)
        g = gn[0]
        names = gn[1]
        gr = [scalib.attacks.FactorGraph(i) for i in g]

        # Amount of traces to keep track of the amount of traces used during the attack.       
        cnt_traces = 0
        cnt_traces_used = 0
        iterobj = attack_dataset.iter_ntraces(None, max_chunk_size=MAX_CHUNK_SIZE)

        # Amount of traces to be processed
        nchunks = len(iterobj)

        # Allocate memory to store the likelihood of obtain for each
        # byte of the key and for each chunks.
        like = np.ones([nchunks,16,256])/256
        idx_good = []
        with open('lut.pickle', 'rb') as file:
            luts = pickle.load(file)
        lp = np.zeros((16, 256))
        key = np.array([200,  30,  77, 124, 100, 9, 163, 92, 133, 124,  56, 162,  99,  18,  51,  47], dtype = np.uint8)
        for cidx,chunk in tqdm.tqdm(enumerate(iterobj),total=len(iterobj)):
            if cidx == 18632:
                break
            # Update counter
            cnt_traces += chunk['traces'].shape[0]
            if cnt_traces < -1:
                continue
            # Counter traces if required. 
            if not(centered):
                utraces = chunk["traces"]
            else:
                utraces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)
                utraces = np.square(utraces)

            # Recover the probability given the leakages values  
            probas_SB = np.array(list(lda_mod_SB.predict_proba(utraces)))
            print(np.array(probas_SB).shape)
            c = 0
            for name in NAMES:
                for i in range(4):
                    for g in range(4):
                        if name+f'_{i}' in names[g]:
                # Get tap signal ID use for profiling of the share
                            A = luts[name][0].astype(dtype=bool)
                            P = chunk["umsk_plaintext"]
                            n = chunk['traces'].shape[0]
                            A = np.tile(A, (n, 1))
                            #print(A.shape)
                            #if i != 3:
                            #    D = luts[name][0][P[:, self.map2[(i+1)*4+g]] ^ key[self.map2[(i+1)*4+g]]]
                            #    if i ==0:
                            #        D = D ^ 1
                            #    for l in range(n):
                            #        A[l] = A[l] ^ D[l]
                            if i == 3:
                                C = np.where(A, probas_SB[c, :, 1][:, None], probas_SB[c, :, 0][:, None])
                                for l in range(n):
                                    C[l] = np.log(C[l][np.arange(256) ^ P[l, self.map2[i*4+g]]])
                                lp[self.map2[4*i +g]] += np.sum(C, axis = 0)
                            c += 1
        keyg = np.argmax(lp, axis = 1)
        cnt_traces = 0
        for cidx,chunk in tqdm.tqdm(enumerate(iterobj),total=len(iterobj)):
            # Update counter
            cnt_traces += chunk['traces'].shape[0]
            if cnt_traces < -1:
                continue
            # Counter traces if required. 
            if not(centered):
                utraces = chunk["traces"]
            else:
                utraces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)
                utraces = np.square(utraces)

            # Recover the probability given the leakages values  
            probas_SB = np.array(list(lda_mod_SB.predict_proba(utraces)))
            print(np.array(probas_SB).shape)
            c = 0
            for name in NAMES:
                for i in range(4):
                    for g in range(4):
                        if name+f'_{i}' in names[g]:
                # Get tap signal ID use for profiling of the share
                            A = luts[name][0].astype(dtype=bool)
                            P = chunk["umsk_plaintext"]
                            n = chunk['traces'].shape[0]
                            A = np.tile(A, (n, 1))
                            #print(A.shape)
                            if i !=3:
                                D = luts[name][0][P[:, self.map2[(i+1)*4+g]] ^ key[self.map2[(i+1)*4+g]]]
                                if i ==0:
                                    D = D ^ 1
                                for l in range(n):
                                    A[l] = A[l] ^ D[l]
                            if i ==2:
                                C = np.where(A, probas_SB[c, :, 1][:, None], probas_SB[c, :, 0][:, None])
                                for l in range(n):
                                    C[l] = np.log(C[l][np.arange(256) ^ P[l, self.map2[i*4+g]]])
                                lp[self.map2[4*i +g]] += np.sum(C, axis = 0)
                            c += 1
        keyg = np.argmax(lp, axis = 1)
        cnt_traces = 0
        for cidx,chunk in tqdm.tqdm(enumerate(iterobj),total=len(iterobj)):
            # Update counter
            cnt_traces += chunk['traces'].shape[0]
            if cnt_traces < -1:
                continue
            # Counter traces if required. 
            if not(centered):
                utraces = chunk["traces"]
            else:
                utraces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)
                utraces = np.square(utraces)

            # Recover the probability given the leakages values  
            probas_SB = np.array(list(lda_mod_SB.predict_proba(utraces)))
            print(np.array(probas_SB).shape)
            c = 0
            for name in NAMES:
                for i in range(4):
                    for g in range(4):
                        if name+f'_{i}' in names[g]:
                # Get tap signal ID use for profiling of the share
                            A = luts[name][0].astype(dtype=bool)
                            P = chunk["umsk_plaintext"]
                            n = chunk['traces'].shape[0]
                            A = np.tile(A, (n, 1))
                            #print(A.shape)
                            if i !=3:
                                D = luts[name][0][P[:, self.map2[(i+1)*4+g]] ^ keyg[self.map2[(i+1)*4+g]]]
                                if i ==0:
                                    D = D ^ 1
                                for l in range(n):
                                    A[l] = A[l] ^ D[l]
                            if i ==1:
                                C = np.where(A, probas_SB[c, :, 1][:, None], probas_SB[c, :, 0][:, None])
                                for l in range(n):
                                    C[l] = np.log(C[l][np.arange(256) ^ P[l, self.map2[i*4+g]]])
                                lp[self.map2[4*i +g]] += np.sum(C, axis = 0)
                            c += 1
 


        # Print some stats about the attack. 
        print("Amount of traces used in attack: {}".format(cnt_traces))

        ## Recombine the sub-results obtained for each chunks.
        # Instead of multiplying probabilities together, we sum the log-probas values obtained
        # to avoid numerical issues. 
        #log_like = np.log2(like)
        #sum_log_like = np.sum(log_like,axis=0) 
        sum_log_like = lp
        # Create key guess object. Here, we give probabilities for each pf the
        # 16-bytes of the unmasked-key. See key_guess.py for more info.  
        kg = KeyGuess(
                [list(range(8*i,8*(i+1))) for i in range(16)],
                (-sum_log_like).tolist()
                )

        # As required, return the KeyGuess object
        return kg


