import numpy as np
from tqdm import tqdm
import key_guess
from scipy.stats import entropy

def common_bits(arr):
    # Convert the array to a list of tuples, where each tuple is (value, index)
    values_indices = [(value, index) for index, value in enumerate(arr)]

    # Sort the list by value
    values_indices.sort()

    # Initialize the dictionary
    common_bits_dict = {}

    # Initialize the current value and the list of indices for this value
    current_value = values_indices[0][0]
    current_indices = [bin(values_indices[0][1])[2:].zfill(8)]

    # Iterate over the rest of the list
    for value, index in values_indices[1:]:
        if value == current_value:
            # If the value is the same as the current value, add the index to the list
            current_indices.append(bin(index)[2:].zfill(8))
        else:
            # If the value is different, compute the common bits for the current value
            common_bits = sum(all(x[i] == '1' for x in current_indices) or all(x[i] == '0' for x in current_indices) for i in range(8))
            common_bits_dict[current_value] = common_bits

            # Start a new list of indices for the new value
            current_value = value
            current_indices = [bin(index)[2:].zfill(8)]

    # Compute the common bits for the last value
    common_bits = sum(all(x[i] == '1' for x in current_indices) or all(x[i] == '0' for x in current_indices) for i in range(8))
    common_bits_dict[current_value] = common_bits

    return common_bits_dict


t = [0]
p = np.ones((128,2))/2
tab = []
for bit in range(8,9):
    for i in range(bit):
        p[i] = [0+0.05*i, 1-0.05*i]
    key = [0] * 128
    kg = key_guess.KeyGuess([[i] for i in range(128)], p)
    for i in tqdm(np.arange(1,2**bit, dtype = np.uint8)):
        a = format(i, f'0{bit}b')
        for j in range(bit):
            key[j] = int(a[-1-j])
        ub = kg.key_rank_ub(key)
        t.append(np.round(np.log2(ub), 1))
    value,counts = np.unique(t, return_counts=True)
    print(common_bits(t))
    tab.append(entropy(counts, base=2))
#plt.plot(np.arange(4,11), tab)
#plt.title("Entropy VS bits")
#plt.show()
