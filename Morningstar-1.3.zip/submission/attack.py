import os
import pickle
from typing import List

from dataset import DatasetReader
from key_guess import KeyGuess

#### Custom import
import numpy as np

import scalib.metrics
import scalib.modeling
import scalib.attacks

from tap_config import TAP_CONFIG, TapConfig, TapSignal
import aeshpc_32bit_d2_lib as plib
import eval_utils
import tqdm

from utils_deep_nets import model_multi_task_sbox_input, model_multi_task_sbox_output , get_hot_encode


# Maximum amount of a chunk. The dataset is read by 
# small part depicted as 'chunks', and this parameter set 
# the maximum size of each chunk. 
MAX_CHUNK_SIZE=16384 

def convert_to_binary(e):
    return [1 if e & (1 << (7-n)) else 0 for n in range(8)]   
class Attack:
    def __init__(self, attack_case: str):
        if attack_case not in ('A7_d2',):
            raise NotImplemented('attack case not implemented')
        self.attack_case = attack_case
        # To be completed.
        # Map to map the location of the sbox input to the ouput sbox
        self.map_in2out_SB = [0,13,10,7,4,1,14,11,8,5,2,15,12,9,6,3]
        self.map_kg = np.array([
            0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11
            ])
        
        indexes = []
        for i in range(21):
            indexes.append(np.arange(70) + 200*i + 143)
        indexes = np.array(indexes).reshape((21*70))
        self.indexes = indexes
   
        
        

    def profile(self, profile_datasets: List[DatasetReader], save_profile):
        # import tensorflow as tf
        # epochs = 20
        # batch_size = 1000
        # n_training = 5000000
        # n_validation =  n_training // 10
        # n_traces = n_training + n_validation
        # tap_cfg = TAP_CONFIG
        
        # dataset_vk0_id = 0
        # for dsi, ds in enumerate(profile_datasets):
        #     if ds.id == "vk0":
        #         dataset_vk0_id = dsi

        # # Dataset instance
        # dataset = profile_datasets[dataset_vk0_id]

        # list_sigs_SB = []
        # for shi in range(2):
        #     for bidx in range(16):
        #         list_sigs_SB.append(self.tapname_byte_fromSB(bidx,shi))
        # for target in ['sbox_output','sbox_input']:
        #     if target == 'sbox_output':      
        #         model_t = 'model_sbox_output_1'
        #         model = model_multi_task_sbox_output()
        #         target_intermediate = 's'
        #         start_index = 8 * 70
        #         end_index = 13 * 70
        #         size = end_index - start_index
        #     elif target == 'sbox_input':
        #         model_t = 'model_sbox_input_1'
        #         model = model_multi_task_sbox_input()
        #         target_intermediate = 't'
        #         start_index = 2 * 70
        #         end_index = 13 * 70
        #         size = end_index - start_index
        #     else:
        #         print('SCOUBIDOU')
                
        #     monitor = 'val_loss'   
        #     mode = 'min'    
            
        #     iterobj = dataset.iter_ntraces(None, max_chunk_size=MAX_CHUNK_SIZE*32)
        #     traces = np.empty((n_traces,size),dtype = np.int16)
        #     labels_target = np.empty((n_traces, 32 ),dtype = np.uint8)
        #     for cidx,chunk in tqdm.tqdm(enumerate(iterobj),total=len(iterobj)):
        #         chunk_traces = chunk['traces'][:171875]
        #         chunk_traces = np.round(chunk_traces - np.mean(chunk_traces,axis=1,keepdims=True)).astype(np.int16)
        #         traces[171875 * cidx:171875 * (cidx + 1)] = chunk_traces[:,self.indexes][:,start_index:end_index]          
                
                
        #         if target == 'sbox_output':
                    
        #             simuls = plib.Simu(
        #                     np.hstack((chunk["seed"][:171875],chunk['msk_plaintext'][:171875],chunk['msk_key'][:171875])),
        #                     110,
        #                     nthreads=64
        #                     )
        
        #             # Recover the data following the same order as for list_sigs_SB
        #             state_v_sbox = np.hstack([
        #                 tap_cfg[sig_name].tap_simu(simuls,c_offset=0,asbyte=True) for sig_name in list_sigs_SB
        #             ])
        #             labels_target[171875 * cidx:171875 * (cidx + 1)]  = state_v_sbox
        #         else:
        #             labels_target[171875 * cidx:171875 * (cidx + 1)] = chunk['msk_plaintext'][:171875] ^ chunk['msk_key'][:171875]
            
        #     map_kg = self.map_kg
            
        #     training_data = traces[:n_training ]
        #     training_labels_x1 = labels_target[:n_training ,:16]
        #     training_labels_x2 = labels_target[:n_training ,16:]   
            
            
        #     X_profiling_dict = {'traces' : training_data}
        #     Y_profiling_dict = {}
            
        #     for byte in range(16):
        #         Y_profiling_dict['{}1_{}'.format(target_intermediate,byte)] = get_hot_encode(training_labels_x1[:,byte] )
        #         Y_profiling_dict['{}2_{}'.format(target_intermediate,byte)] = get_hot_encode(training_labels_x2[:,byte] )
                
        #     if target == 'sbox_input':
        #         for branch in range(4):
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(training_labels_x1[:,map_kg[4*branch]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch]],1), np.expand_dims(training_labels_x1[:,map_kg[4*branch +1]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch+1]],1), np.expand_dims(training_labels_x1[:,map_kg[4*branch +2]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch+2]],1), np.expand_dims(training_labels_x1[:,map_kg[4*branch +3]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch+3]],1)],axis = 1),axis = 1)
        #             Y_profiling_dict['t_sig_{}'.format(branch)] = labels_sig
        #     else:
        #         for branch in range(8):   
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(training_labels_x1[:,2*branch],1), np.expand_dims(training_labels_x2[:,2*branch],1), np.expand_dims(training_labels_x1[:,2*branch+1],1), np.expand_dims(training_labels_x2[:,2*branch+1],1)],axis = 1),axis = 1)
        #             Y_profiling_dict['s_sig_{}'.format(branch)] = labels_sig
                        
            
        #     validation_data = traces[n_training:n_training + n_validation]
        #     X_validation_dict = {'traces' : validation_data}
            
        #     validation_labels_x1 = labels_target[n_training:n_training + n_validation,:16]
        #     validation_labels_x2 = labels_target[n_training:n_training + n_validation,16:]
            
        #     Y_validation_dict = {}
        #     for byte in range(16):
        #         Y_validation_dict['{}1_{}'.format(target_intermediate,byte)] = get_hot_encode(validation_labels_x1[:,byte] )
        #         Y_validation_dict['{}2_{}'.format(target_intermediate,byte)] = get_hot_encode(validation_labels_x2[:,byte] )
           
        #     if target == 'sbox_input':
        #         for branch in range(4):
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(validation_labels_x1[:,map_kg[4*branch]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch]],1), np.expand_dims(validation_labels_x1[:,map_kg[4*branch +1]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch+1]],1), np.expand_dims(validation_labels_x1[:,map_kg[4*branch +2]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch+2]],1), np.expand_dims(validation_labels_x1[:,map_kg[4*branch +3]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch+3]],1)],axis = 1),axis = 1)
        #             Y_validation_dict['t_sig_{}'.format(branch)] = labels_sig
        #     else:
        #         for branch in range(8):   
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(validation_labels_x1[:,2*branch],1), np.expand_dims(validation_labels_x2[:,2*branch],1), np.expand_dims(validation_labels_x1[:,2*branch+1],1), np.expand_dims(validation_labels_x2[:,2*branch+1],1)],axis = 1),axis = 1)
        #             Y_validation_dict['s_sig_{}'.format(branch)] = labels_sig
            
            
        #     training_data , validation_data = tf.data.Dataset.from_tensor_slices((X_profiling_dict ,Y_profiling_dict)), tf.data.Dataset.from_tensor_slices(( X_validation_dict,Y_validation_dict)) 
            
        #     training_data = training_data.shuffle(len(training_data)).batch(batch_size)    
        #     validation_data = validation_data.batch(batch_size)
            

        #     if save_profile :
        #         callbacks = tf.keras.callbacks.ModelCheckpoint(
        #                                     filepath= save_profile +'/'+ model_t +'.h5',
        #                                     save_weights_only=True,
        #                                     monitor=monitor,
        #                                     mode=mode,
        #                                     save_best_only=True)
                
        #         os.makedirs(save_profile, exist_ok=True)
        #         history = model.fit(training_data, batch_size=batch_size, verbose = 'auto', epochs=epochs, validation_data=validation_data,callbacks =callbacks)
        #     else:
        #         print('BEST MODEL IS USUALLY SAVED ON DISK USING A CALLBACK MONITORING THE VAL LOSS. HERE THE MODEL OF THE LAST EPOCH IS CHOSEN (MIGHT NOT BE THE BEST). THE MODELS SIZE ARE ABOUT 500KB...')
        #         history = model.fit(training_data, batch_size=batch_size, verbose = 'auto', epochs=epochs, validation_data=validation_data)
                
        #     if target == 'sbox_output':      
        #         self.model_sbox = model
        #     elif target == 'sbox_input':
        #         self.model_sbox_input = model
        #     else:
        #         print('SCOUBIDOU')            
        return
    def attack(self, attack_dataset: DatasetReader, attack_path) -> KeyGuess: 
     
        import sasca_utils 
       
        
        # Create the factor graph that will be used. 
        graph = scalib.attacks.FactorGraph(sasca_utils.SASCA_GRAPH_D2_Y, {"sbox":sasca_utils.SBOX}) 

        # Amount of traces to keep track of the amount of traces used during the attack.       
        cnt_traces = 0
        iterobj = attack_dataset.iter_ntraces(None, max_chunk_size=MAX_CHUNK_SIZE)

        # Amount of traces to be processed
        nchunks = len(iterobj)
        # Allocate memory to store the likelihood of obtain for each
        # byte of the key and for each chunks.
        like = np.zeros([nchunks,16,256])
        pbar = tqdm.tqdm(enumerate(iterobj),total=len(iterobj))
        for cidx,chunk in pbar:
            # Update counter 
            cnt_traces += chunk['traces'].shape[0]

            # Counter traces if required. 
            # Recover the probability given the leakages values  
            traces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)
            traces = traces[:,self.indexes]
            

            predictions_sbox = self.model_sbox.predict({'traces' : traces[:,70*8:70*13]},batch_size = 500,verbose = 0)
            predictions_sbox_input = self.model_sbox_input.predict({'traces' : traces[:,140:13*70]},batch_size = 500,verbose = 0)
            
            # Fetch amount of traces in the chunk
            ntraces = chunk['traces'].shape[0]
            # # Create the graphs
            graphs = [scalib.attacks.BPState(graph,ntraces,{"p":chunk["umsk_plaintext"][:,bidx].astype(np.uint32)}) for bidx in range(16)]

            # Set the distributions for each graph
            for shi in range(2):
                for bidx in range(16):
                    # Get tap signal ID use for profiling of the share
                    graphs[bidx].set_evidence("t{}".format(shi),predictions_sbox_input['t{}_{}'.format(shi+1,bidx)])
                    graphs[bidx].set_evidence("s{}".format(shi),predictions_sbox['s{}_{}'.format(shi+1,self.map_in2out_SB[bidx])])

            # Execute the belief propagation computation. 
            nthread = 16
            if nthread==1:
                ## Single thread run
                for g in graphs:
                    g.bp_acyclic("k")
            else:
                ## Multi thread run
                mpf = lambda g: g.bp_acyclic("k")
                with scalib.tools.ContextExecutor(max_workers=nthread) as e:
                    results = list(e.map(mpf,graphs)) 

            # Recover the probabilities of the key bytes. 
            for gi, g in enumerate(graphs):
                like[cidx,gi,:] = g.get_distribution("k")
                
        log_like = np.log2(like)
        
        sum_log_like = np.sum(log_like,axis=0) 
            

            # Create key guess object. Here, we give probabilities for each pf the
            # 16-bytes of the unmasked-key. See key_guess.py for more info.  
        kg = KeyGuess(
                    [list(range(8*i,8*(i+1))) for i in range(16)],
                    (-sum_log_like).tolist()
                    )
                    
        print("Amount of traces used in attack: {}".format(cnt_traces))

        return kg 

    # DO NOT MODIFY! 
    def save_profile(self, profile_dir: str):
        
        return


    def load_profile(self, profile_dir: str):

        self.model_sbox = self.make_model_sbox(profile_dir)    
        self.model_sbox_input = self.make_model_sbox_input(profile_dir)  
        
         
    ## Create structures and load weights from the saved files.
    
    def make_model_sbox(self, profile_dir: str):
        structure_model_sbox = model_multi_task_sbox_output()
        model_file ='.'+ profile_dir + '/model_sbox_output.h5'
        structure_model_sbox.load_weights(model_file)
        return structure_model_sbox   

    def make_model_sbox_input(self, profile_dir: str):
        structure_model_sbox_input = model_multi_task_sbox_input()
        model_file = '.'+ profile_dir + '/model_sbox_input.h5'
        structure_model_sbox_input.load_weights(model_file)
        return  structure_model_sbox_input
  

    # From a byte id, return the location in the matrix representation of the
    # state. The location is representation as a pair of indexes, one for the
    # row, and one for the column. 
    def id2loc(self,bid):
        colid = bid // 4
        rowid = bid % 4
        return (rowid,colid)

    # Return the sharing part of the TapSignal instance (see TapSignal definition in tap_config.py for more details).
    def strshi(self, shi):
        return 'r' if shi == None else shi

    # Return the string id of a single byte of the state after the Sboxes. In
    # particular, bidx is the index of the byte (in [0,15]) and shi is the
    # index of the share (in [0,1]).
    def tapname_byte_fromSB(self, bidx,shi, round_id=0):
        # Fetch byte location for bidx
        (rid, cid) = self.id2loc(bidx) 
        # Clock index
        # Here:
        # - the +1 is used to take into account the first cycle of the execution, during 
        # which the KeySchedule of the first round starts. 
        # - the +6 is used to take into account the Sbox latency.  
        c2t = cid + 6 + 1 + 10*round_id 
        # Return the indentifier. 
        tapsig_yi = "B_fromSB__{}.{}.{}.0:7.raw".format(rid,c2t,self.strshi(shi))
        return tapsig_yi

