import os
import pickle
from typing import List

from dataset import DatasetReader
from key_guess import KeyGuess

#### Custom import
import numpy as np

import scalib.metrics
import scalib.modeling
import scalib.attacks

from tap_config import TAP_CONFIG, TapConfig, TapSignal
import aeshpc_32bit_d2_lib as plib
import eval_utils
import tqdm
import itertools

from utils_deep_nets import model_multi_task_sbox_input, get_hot_encode  , XorLayer ,  model_multi_task_sbox_input_transitions ,model_multi_task_sbox_input_sec, model_single_task_key , model_multi_task_sbox_input_column
import tensorflow as tf

# Maximum amount of a chunk. The dataset is read by 
# small part depicted as 'chunks', and this parameter set 
# the maximum size of each chunk. 
MAX_CHUNK_SIZE=16384//4
def convert_to_binary(e):
    return [1 if e & (1 << (7-n)) else 0 for n in range(8)]   
def softmax(x) :
    x = x/np.max(x)
    return np.exp(x)/np.sum(np.exp(x))
class Attack:
    def __init__(self, attack_case: str):
        self.attack_case = attack_case
        print(self.attack_case )
        # To be completed.
        # Map to map the location of the sbox input to the ouput sbox
        self.map_in2out_SB = [0,13,10,7,4,1,14,11,8,5,2,15,12,9,6,3]
        self.map_kg = np.array([
            0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11
            ])
        
        indexes = []
        delta = 190 if self.attack_case == 'S6_d2' else 143
        
        for i in range(0,21):
            indexes.append(np.arange(70) + 200*i + delta)
                        
        indexes = np.array(indexes).reshape((21*70))   
        self.indexes = indexes
        indexes_trans = []
        for i in range(4,12):    
            indexes_trans.append(np.arange(200) + 200*i + delta)
                        
        indexes_trans= np.array(indexes_trans).reshape((8*200))
        
        self.indexes_trans = indexes_trans
        indexes_keys = []
        for i in range(2,9):    
            indexes_keys .append(np.arange(200) + 200*i + delta)
                        
        indexes_keys = np.array(indexes_keys ).reshape((7*200))
        
        self.indexes_keys = indexes_keys 
     
        self.xor_layer = XorLayer(name = 'xor')
        mean_A7 = np.load('mean_traces_A7.npy')
        mean_S6 = np.load('mean_traces_S6.npy')
        offset =( mean_A7 - mean_S6).astype(np.int16)
        self.offset = offset
   
        
        

    def profile(self, profile_datasets: List[DatasetReader], save_profile):
        # import tensorflow as tf
        # epochs = 20
        # batch_size = 1000
        # n_training = 5000000
        # n_validation =  n_training // 10
        # n_traces = n_training + n_validation
        # tap_cfg = TAP_CONFIG
        
        # dataset_vk0_id = 0
        # for dsi, ds in enumerate(profile_datasets):
        #     if ds.id == "vk0":
        #         dataset_vk0_id = dsi

        # # Dataset instance
        # dataset = profile_datasets[dataset_vk0_id]

        # list_sigs_SB = []
        # for shi in range(2):
        #     for bidx in range(16):
        #         list_sigs_SB.append(self.tapname_byte_fromSB(bidx,shi))
        # for target in ['sbox_output','sbox_input']:
        #     if target == 'sbox_output':      
        #         model_t = 'model_sbox_output_1'
        #         model = model_multi_task_sbox_output()
        #         target_intermediate = 's'
        #         start_index = 8 * 70
        #         end_index = 13 * 70
        #         size = end_index - start_index
        #     elif target == 'sbox_input':
        #         model_t = 'model_sbox_input_1'
        #         model = model_multi_task_sbox_input()
        #         target_intermediate = 't'
        #         start_index = 2 * 70
        #         end_index = 13 * 70
        #         size = end_index - start_index
        #     else:
        #         print('SCOUBIDOU')
                
        #     monitor = 'val_loss'   
        #     mode = 'min'    
            
        #     iterobj = dataset.iter_ntraces(None, max_chunk_size=MAX_CHUNK_SIZE*32)
        #     traces = np.empty((n_traces,size),dtype = np.int16)
        #     labels_target = np.empty((n_traces, 32 ),dtype = np.uint8)
        #     for cidx,chunk in tqdm.tqdm(enumerate(iterobj),total=len(iterobj)):
        #         chunk_traces = chunk['traces'][:171875]
        #         chunk_traces = np.round(chunk_traces - np.mean(chunk_traces,axis=1,keepdims=True)).astype(np.int16)
        #         traces[171875 * cidx:171875 * (cidx + 1)] = chunk_traces[:,self.indexes][:,start_index:end_index]          
                
                
        #         if target == 'sbox_output':
                    
        #             simuls = plib.Simu(
        #                     np.hstack((chunk["seed"][:171875],chunk['msk_plaintext'][:171875],chunk['msk_key'][:171875])),
        #                     110,
        #                     nthreads=64
        #                     )
        
        #             # Recover the data following the same order as for list_sigs_SB
        #             state_v_sbox = np.hstack([
        #                 tap_cfg[sig_name].tap_simu(simuls,c_offset=0,asbyte=True) for sig_name in list_sigs_SB
        #             ])
        #             labels_target[171875 * cidx:171875 * (cidx + 1)]  = state_v_sbox
        #         else:
        #             labels_target[171875 * cidx:171875 * (cidx + 1)] = chunk['msk_plaintext'][:171875] ^ chunk['msk_key'][:171875]
            
        #     map_kg = self.map_kg
            
        #     training_data = traces[:n_training ]
        #     training_labels_x1 = labels_target[:n_training ,:16]
        #     training_labels_x2 = labels_target[:n_training ,16:]   
            
            
        #     X_profiling_dict = {'traces' : training_data}
        #     Y_profiling_dict = {}
            
        #     for byte in range(16):
        #         Y_profiling_dict['{}1_{}'.format(target_intermediate,byte)] = get_hot_encode(training_labels_x1[:,byte] )
        #         Y_profiling_dict['{}2_{}'.format(target_intermediate,byte)] = get_hot_encode(training_labels_x2[:,byte] )
                
        #     if target == 'sbox_input':
        #         for branch in range(4):
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(training_labels_x1[:,map_kg[4*branch]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch]],1), np.expand_dims(training_labels_x1[:,map_kg[4*branch +1]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch+1]],1), np.expand_dims(training_labels_x1[:,map_kg[4*branch +2]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch+2]],1), np.expand_dims(training_labels_x1[:,map_kg[4*branch +3]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch+3]],1)],axis = 1),axis = 1)
        #             Y_profiling_dict['t_sig_{}'.format(branch)] = labels_sig
        #     else:
        #         for branch in range(8):   
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(training_labels_x1[:,2*branch],1), np.expand_dims(training_labels_x2[:,2*branch],1), np.expand_dims(training_labels_x1[:,2*branch+1],1), np.expand_dims(training_labels_x2[:,2*branch+1],1)],axis = 1),axis = 1)
        #             Y_profiling_dict['s_sig_{}'.format(branch)] = labels_sig
                        
            
        #     validation_data = traces[n_training:n_training + n_validation]
        #     X_validation_dict = {'traces' : validation_data}
            
        #     validation_labels_x1 = labels_target[n_training:n_training + n_validation,:16]
        #     validation_labels_x2 = labels_target[n_training:n_training + n_validation,16:]
            
        #     Y_validation_dict = {}
        #     for byte in range(16):
        #         Y_validation_dict['{}1_{}'.format(target_intermediate,byte)] = get_hot_encode(validation_labels_x1[:,byte] )
        #         Y_validation_dict['{}2_{}'.format(target_intermediate,byte)] = get_hot_encode(validation_labels_x2[:,byte] )
           
        #     if target == 'sbox_input':
        #         for branch in range(4):
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(validation_labels_x1[:,map_kg[4*branch]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch]],1), np.expand_dims(validation_labels_x1[:,map_kg[4*branch +1]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch+1]],1), np.expand_dims(validation_labels_x1[:,map_kg[4*branch +2]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch+2]],1), np.expand_dims(validation_labels_x1[:,map_kg[4*branch +3]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch+3]],1)],axis = 1),axis = 1)
        #             Y_validation_dict['t_sig_{}'.format(branch)] = labels_sig
        #     else:
        #         for branch in range(8):   
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(validation_labels_x1[:,2*branch],1), np.expand_dims(validation_labels_x2[:,2*branch],1), np.expand_dims(validation_labels_x1[:,2*branch+1],1), np.expand_dims(validation_labels_x2[:,2*branch+1],1)],axis = 1),axis = 1)
        #             Y_validation_dict['s_sig_{}'.format(branch)] = labels_sig
            
            
        #     training_data , validation_data = tf.data.Dataset.from_tensor_slices((X_profiling_dict ,Y_profiling_dict)), tf.data.Dataset.from_tensor_slices(( X_validation_dict,Y_validation_dict)) 
            
        #     training_data = training_data.shuffle(len(training_data)).batch(batch_size)    
        #     validation_data = validation_data.batch(batch_size)
            

        #     if save_profile :
        #         callbacks = tf.keras.callbacks.ModelCheckpoint(
        #                                     filepath= save_profile +'/'+ model_t +'.h5',
        #                                     save_weights_only=True,
        #                                     monitor=monitor,
        #                                     mode=mode,
        #                                     save_best_only=True)
                
        #         os.makedirs(save_profile, exist_ok=True)
        #         history = model.fit(training_data, batch_size=batch_size, verbose = 'auto', epochs=epochs, validation_data=validation_data,callbacks =callbacks)
        #     else:
        #         print('BEST MODEL IS USUALLY SAVED ON DISK USING A CALLBACK MONITORING THE VAL LOSS. HERE THE MODEL OF THE LAST EPOCH IS CHOSEN (MIGHT NOT BE THE BEST). THE MODELS SIZE ARE ABOUT 500KB...')
        #         history = model.fit(training_data, batch_size=batch_size, verbose = 'auto', epochs=epochs, validation_data=validation_data)
                
        #     if target == 'sbox_output':      
        #         self.model_sbox = model
        #     elif target == 'sbox_input':
        #         self.model_sbox_input = model
        #     else:
        #         print('SCOUBIDOU')            
        return
    def attack(self, attack_dataset: DatasetReader, attack_path) -> KeyGuess: 
       
        cnt_traces = 0
        iterobj = attack_dataset.iter_ntraces(None, max_chunk_size=MAX_CHUNK_SIZE)

        # Amount of traces to be processed
        nchunks = len(iterobj)
        # Allocate memory to store the likelihood of obtain for each
        # byte of the key and for each chunks.
        like = np.zeros([nchunks,16,256])
        pbar = tqdm.tqdm(enumerate(iterobj),total=len(iterobj))
        
        first_bytes = [12,1,6,11]
        second_bytes = [8,13,2,7]
       
        
        x7_11 = np.empty((nchunks*MAX_CHUNK_SIZE,256),dtype = np.float64)
        x3_7 = np.empty((nchunks*MAX_CHUNK_SIZE,256),dtype = np.float64)
        x15_3 = np.empty((nchunks*MAX_CHUNK_SIZE,256),dtype = np.float64)
        x12_15 = np.empty((nchunks*MAX_CHUNK_SIZE,256),dtype = np.float64)
        
        x8_12 = np.empty((nchunks*MAX_CHUNK_SIZE,256),dtype = np.float64)
        x4_8= np.empty((nchunks*MAX_CHUNK_SIZE,256),dtype = np.float64)
        x0_4 = np.empty((nchunks*MAX_CHUNK_SIZE,256),dtype = np.float64)       

        for cidx,chunk in pbar:
            # Update counter 
            cnt_traces += chunk['traces'].shape[0]
            ntraces = chunk['traces'].shape[0]


            traces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)      
            traces = traces[:,self.indexes]
            traces = traces[:,140:13*70]
            

            predictions = self.model_inputs.predict(traces,batch_size = 500, verbose= 0)
         
            for byte in first_bytes: 
                plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,byte])
                t = predictions['t_{}'.format(byte)] 
                k_from_t =self.xor_layer([t,plaintexts])
                
                like[cidx,byte] = np.sum(np.log2(k_from_t ),axis = 0) 
        sum_log_like = np.sum(like,axis = 0)  
        value_byte = []
        for byte in first_bytes:
            value_byte.append(tf.nn.softmax(sum_log_like[byte]).reshape(1,256))

        pbar = tqdm.tqdm(enumerate(iterobj),total=len(iterobj))
        for cidx,chunk in pbar:
            cnt_traces += chunk['traces'].shape[0]
            ntraces = chunk['traces'].shape[0]
            
            traces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)
            traces_trans = traces[:,self.indexes_trans]  + self.offset[400:2000]                      
            predictions = self.model_transitions.predict(traces_trans,batch_size = 500, verbose= 0)
            count = 0
                     
            transition = predictions['t_{}'.format(7)] 
            plaintexts_trans = get_hot_encode(chunk['umsk_plaintext'][:,11])                
            t_from_tran =tf.cast(plaintexts_trans,tf.float64)
            t_from_tran =self.xor_layer([t_from_tran ,transition])
            plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,7])  
            x7_11[cidx*MAX_CHUNK_SIZE:(cidx+1)* MAX_CHUNK_SIZE] =np.log2(self.xor_layer([t_from_tran ,plaintexts]))
            
            transition = predictions['t_{}'.format(3)] 
            plaintexts_trans = get_hot_encode(chunk['umsk_plaintext'][:,7])                
            t_from_tran =tf.cast(plaintexts_trans,tf.float64)
            t_from_tran =self.xor_layer([t_from_tran ,transition])
            plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,3])  
            x3_7[cidx*MAX_CHUNK_SIZE:(cidx+1)* MAX_CHUNK_SIZE] =np.log2(self.xor_layer([t_from_tran ,plaintexts]))

            transition = predictions['t_{}'.format(15)] 
            plaintexts_trans = get_hot_encode(chunk['umsk_plaintext'][:,3])                
            t_from_tran =tf.cast(plaintexts_trans,tf.float64)
            t_from_tran =self.xor_layer([t_from_tran ,transition])
            plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,15])  
            x15_3[cidx*MAX_CHUNK_SIZE:(cidx+1)* MAX_CHUNK_SIZE] =np.log2(self.xor_layer([t_from_tran ,plaintexts]))

            transition = predictions['t_{}'.format(8)] 
            plaintexts_trans = get_hot_encode(chunk['umsk_plaintext'][:,12])                
            t_from_tran =tf.cast(plaintexts_trans,tf.float64)
            t_from_tran =self.xor_layer([t_from_tran ,transition])
            plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,8])  
            x8_12[cidx*MAX_CHUNK_SIZE:(cidx+1)* MAX_CHUNK_SIZE] =np.log2(self.xor_layer([t_from_tran ,plaintexts]))
            
            transition = predictions['t_{}'.format(4)] 
            plaintexts_trans = get_hot_encode(chunk['umsk_plaintext'][:,8])                
            t_from_tran =tf.cast(plaintexts_trans,tf.float64)
            t_from_tran =self.xor_layer([t_from_tran ,transition])
            plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,4])  
            x4_8[cidx*MAX_CHUNK_SIZE:(cidx+1)* MAX_CHUNK_SIZE] = np.log2(self.xor_layer([t_from_tran ,plaintexts]))

            transition = predictions['t_{}'.format(0)] 
            plaintexts_trans = get_hot_encode(chunk['umsk_plaintext'][:,4])                
            t_from_tran =tf.cast(plaintexts_trans,tf.float64)
            t_from_tran =self.xor_layer([t_from_tran ,transition])
            plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,0])  
            x0_4[cidx*MAX_CHUNK_SIZE:(cidx+1)* MAX_CHUNK_SIZE] =np.log2(self.xor_layer([t_from_tran ,plaintexts]))
       
        n_traces = nchunks * MAX_CHUNK_SIZE
        x11 = np.argmax(sum_log_like[11])
        print(x11)        
        x12 = np.argmax(sum_log_like[12])  
        
        x_12_encoded = get_hot_encode(x12).reshape((1,256))
        sum_x8_12 = np.sum(x8_12,axis = 0)
        sum_x8_12 = tf.nn.softmax(sum_x8_12)
        
        sum_x4_8 = np.sum(x4_8,axis = 0)
        sum_x4_8 = tf.nn.softmax(sum_x4_8)

        sum_x0_4 = np.sum(x0_4,axis = 0)
        sum_x0_4 = tf.nn.softmax(sum_x0_4)

        
        scores_x8 = self.xor_layer([sum_x8_12.reshape((1,256)),x_12_encoded])
        scores_x4 = self.xor_layer([sum_x4_8.reshape((1,256)),scores_x8])
        scores_x0 = self.xor_layer([sum_x0_4.reshape((1,256)),scores_x4])

  
        x_11_encoded = get_hot_encode(x11).reshape((1,256))
        sum_x7_11 = np.sum(x7_11,axis = 0)
        sum_x7_11 = tf.nn.softmax(sum_x7_11)
        
        sum_x3_7 = np.sum(x3_7,axis = 0)
        sum_x3_7 = tf.nn.softmax(sum_x3_7)

        sum_x15_3 = np.sum(x15_3,axis = 0)
        sum_x15_3 = tf.nn.softmax( sum_x15_3)

        
        scores_x7 = self.xor_layer([sum_x7_11.reshape((1,256)),x_11_encoded])
        scores_x3 = self.xor_layer([sum_x3_7.reshape((1,256)),scores_x7])
        scores_x15 = self.xor_layer([sum_x15_3.reshape((1,256)),scores_x3])

       
        
            
        
        sum_log_like = np.sum(like,axis = 0)  
        sum_log_like[7] = np.log2(scores_x7)
        sum_log_like[3] = np.log2(scores_x3)
        sum_log_like[15] = np.log2(scores_x15)
        sum_log_like[8] = np.log2(scores_x8)
        sum_log_like[4] = np.log2(scores_x4)
        sum_log_like[0] = np.log2(scores_x0)              
                 

            

            # Create key guess object. Here, we give probabilities for each pf the
            # 16-bytes of the unmasked-key. See key_guess.py for more info.  
        kg = KeyGuess(
                    [list(range(8*i,8*(i+1))) for i in range(16)],
                    (-sum_log_like).tolist()
                    )    

        return kg 

    # DO NOT MODIFY! 
    def save_profile(self, profile_dir: str):
        
        return


    def load_profile(self, profile_dir: str):
        
        self.model_inputs = self.make_model_sbox_input(profile_dir)
        self.model_transitions = self.make_model_sbox_input_transitions(profile_dir)
                
    ## Create structures and load weights from the saved files.
 
    def make_model_sbox_input_transitions(self, profile_dir: str):
        structure_model_sbox_input_transitions = model_multi_task_sbox_input_transitions(labels_mask = True)               
        new_input = tf.keras.layers.Input((200*8,),name = 'traces')   
        new_model = structure_model_sbox_input_transitions(new_input)
        outputs= {}
        map_kg = np.array([
               15,3,7
              ])     
        for byte in map_kg:
            x = self.xor_layer([new_model['t1_{}'.format(byte)], new_model['t2_before_soft_{}'.format(byte)]])
            outputs['t_{}'.format(byte)] = tf.keras.layers.Softmax(name = 't_{}'.format(byte))(x)
        model_3 = tf.keras.models.Model(inputs = new_input,outputs= outputs) 
        model_file = '.'+ profile_dir + '/model_sbox_input_trans_7_3_15{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        model_3.load_weights(model_file)
        
        
        structure = model_multi_task_sbox_input_column(0,labels_mask = False)               
        new_input = tf.keras.layers.Input((200*8,),name = 'traces')   
        new_model = structure(new_input)
        outputs= {}
        map_kg = np.array([
               0,4,8
              ])     
        for byte in map_kg:
            x = self.xor_layer([new_model['t1_{}'.format(byte)], new_model['t2_before_soft_{}'.format(byte)]])
            outputs['t_{}'.format(byte)] = tf.keras.layers.Softmax(name = 't_{}'.format(byte))(x)
        model_0 = tf.keras.models.Model(inputs = new_input,outputs= outputs) 
        model_file = '.'+ profile_dir + '/model_t_column_0{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        model_0.load_weights(model_file)
        
        new_input = tf.keras.layers.Input((200*8,),name = 'traces')
        outputs = {}
        model_0 = model_0(new_input)
        model_3 = model_3(new_input)
        
        for k , v in model_0.items():
            outputs[k] = v
        
        for k , v in model_3.items():
            outputs[k] = v        
        
        model = tf.keras.models.Model(inputs = new_input,outputs= outputs) 
        return  model

   

    def make_model_sbox_input(self, profile_dir: str):
        structure_model_sbox_input = model_multi_task_sbox_input(labels_mask = False)
        model_file = '.'+ profile_dir + '/model_sbox_input{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        structure_model_sbox_input.load_weights(model_file,by_name = True)
        return  structure_model_sbox_input
   

    # From a byte id, return the location in the matrix representation of the
    # state. The location is representation as a pair of indexes, one for the
    # row, and one for the column. 
    def id2loc(self,bid):
        colid = bid // 4
        rowid = bid % 4
        return (rowid,colid)

    # Return the sharing part of the TapSignal instance (see TapSignal definition in tap_config.py for more details).
    def strshi(self, shi):
        return 'r' if shi == None else shi

    # Return the string id of a single byte of the state after the Sboxes. In
    # particular, bidx is the index of the byte (in [0,15]) and shi is the
    # index of the share (in [0,1]).
    def tapname_byte_fromSB(self, bidx,shi, round_id=0):
        # Fetch byte location for bidx
        (rid, cid) = self.id2loc(bidx) 
        # Clock index
        # Here:
        # - the +1 is used to take into account the first cycle of the execution, during 
        # which the KeySchedule of the first round starts. 
        # - the +6 is used to take into account the Sbox latency.  
        c2t = cid + 6 + 1 + 10*round_id 
        # Return the indentifier. 
        tapsig_yi = "B_fromSB__{}.{}.{}.0:7.raw".format(rid,c2t,self.strshi(shi))
        return tapsig_yi

