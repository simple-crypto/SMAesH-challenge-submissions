import os
import pickle
from typing import List

from dataset import DatasetReader
from key_guess import KeyGuess

#### Custom import
import numpy as np

import scalib.metrics
import scalib.modeling
import scalib.attacks

from tap_config import TAP_CONFIG, TapConfig, TapSignal
import aeshpc_32bit_d2_lib as plib
import eval_utils
import tqdm
import itertools

from utils_deep_nets import  get_hot_encode  , XorLayer ,  model_multi_task_sbox_input_transitions , model_multi_task_sbox_input_column , model_multi_task_sbox_input, model_single_task_key ,model_multi_task_key_transitions
import tensorflow as tf

# Maximum amount of a chunk. The dataset is read by 
# small part depicted as 'chunks', and this parameter set 
# the maximum size of each chunk. 
MAX_CHUNK_SIZE=16384//4
def convert_to_binary(e):
    return [1 if e & (1 << (7-n)) else 0 for n in range(8)]   
def softmax(x) :
    x = x/np.max(x)
    return np.exp(x)/np.sum(np.exp(x))
class Attack:
    def __init__(self, attack_case: str):
        self.attack_case = attack_case
        print(self.attack_case )
        # To be completed.
        # Map to map the location of the sbox input to the ouput sbox
        self.map_in2out_SB = [0,13,10,7,4,1,14,11,8,5,2,15,12,9,6,3]
        self.map_kg = np.array([
            0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11
            ])
        
        indexes = []
        delta = 190 if self.attack_case == 'S6_d2' else 143
        
        for i in range(0,21):
            indexes.append(np.arange(70) + 200*i + delta)
                        
        indexes = np.array(indexes).reshape((21*70))   
        self.indexes = indexes
        indexes_trans = []
        for i in range(4,12):    
            indexes_trans.append(np.arange(200) + 200*i + delta)
                        
        indexes_trans= np.array(indexes_trans).reshape((8*200))
        
        self.indexes_trans = indexes_trans
        indexes_keys = []
        for i in range(2,9):    
            indexes_keys .append(np.arange(200) + 200*i + delta)
                        
        indexes_keys = np.array(indexes_keys ).reshape((7*200))
        
        self.indexes_keys = indexes_keys 
     
        self.xor_layer = XorLayer(name = 'xor')
        mean_A7 = np.load('mean_traces_A7.npy')
        mean_S6 = np.load('mean_traces_S6.npy')
        offset =( mean_A7 - mean_S6).astype(np.int16)
        self.offset = offset
   
        
        

    def profile(self, profile_datasets: List[DatasetReader], save_profile):
        # import tensorflow as tf
        # epochs = 20
        # batch_size = 1000
        # n_training = 5000000
        # n_validation =  n_training // 10
        # n_traces = n_training + n_validation
        # tap_cfg = TAP_CONFIG
        
        # dataset_vk0_id = 0
        # for dsi, ds in enumerate(profile_datasets):
        #     if ds.id == "vk0":
        #         dataset_vk0_id = dsi

        # # Dataset instance
        # dataset = profile_datasets[dataset_vk0_id]

        # list_sigs_SB = []
        # for shi in range(2):
        #     for bidx in range(16):
        #         list_sigs_SB.append(self.tapname_byte_fromSB(bidx,shi))
        # for target in ['sbox_output','sbox_input']:
        #     if target == 'sbox_output':      
        #         model_t = 'model_sbox_output_1'
        #         model = model_multi_task_sbox_output()
        #         target_intermediate = 's'
        #         start_index = 8 * 70
        #         end_index = 13 * 70
        #         size = end_index - start_index
        #     elif target == 'sbox_input':
        #         model_t = 'model_sbox_input_1'
        #         model = model_multi_task_sbox_input()
        #         target_intermediate = 't'
        #         start_index = 2 * 70
        #         end_index = 13 * 70
        #         size = end_index - start_index
        #     else:
        #         print('SCOUBIDOU')
                
        #     monitor = 'val_loss'   
        #     mode = 'min'    
            
        #     iterobj = dataset.iter_ntraces(None, max_chunk_size=MAX_CHUNK_SIZE*32)
        #     traces = np.empty((n_traces,size),dtype = np.int16)
        #     labels_target = np.empty((n_traces, 32 ),dtype = np.uint8)
        #     for cidx,chunk in tqdm.tqdm(enumerate(iterobj),total=len(iterobj)):
        #         chunk_traces = chunk['traces'][:171875]
        #         chunk_traces = np.round(chunk_traces - np.mean(chunk_traces,axis=1,keepdims=True)).astype(np.int16)
        #         traces[171875 * cidx:171875 * (cidx + 1)] = chunk_traces[:,self.indexes][:,start_index:end_index]          
                
                
        #         if target == 'sbox_output':
                    
        #             simuls = plib.Simu(
        #                     np.hstack((chunk["seed"][:171875],chunk['msk_plaintext'][:171875],chunk['msk_key'][:171875])),
        #                     110,
        #                     nthreads=64
        #                     )
        
        #             # Recover the data following the same order as for list_sigs_SB
        #             state_v_sbox = np.hstack([
        #                 tap_cfg[sig_name].tap_simu(simuls,c_offset=0,asbyte=True) for sig_name in list_sigs_SB
        #             ])
        #             labels_target[171875 * cidx:171875 * (cidx + 1)]  = state_v_sbox
        #         else:
        #             labels_target[171875 * cidx:171875 * (cidx + 1)] = chunk['msk_plaintext'][:171875] ^ chunk['msk_key'][:171875]
            
        #     map_kg = self.map_kg
            
        #     training_data = traces[:n_training ]
        #     training_labels_x1 = labels_target[:n_training ,:16]
        #     training_labels_x2 = labels_target[:n_training ,16:]   
            
            
        #     X_profiling_dict = {'traces' : training_data}
        #     Y_profiling_dict = {}
            
        #     for byte in range(16):
        #         Y_profiling_dict['{}1_{}'.format(target_intermediate,byte)] = get_hot_encode(training_labels_x1[:,byte] )
        #         Y_profiling_dict['{}2_{}'.format(target_intermediate,byte)] = get_hot_encode(training_labels_x2[:,byte] )
                
        #     if target == 'sbox_input':
        #         for branch in range(4):
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(training_labels_x1[:,map_kg[4*branch]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch]],1), np.expand_dims(training_labels_x1[:,map_kg[4*branch +1]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch+1]],1), np.expand_dims(training_labels_x1[:,map_kg[4*branch +2]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch+2]],1), np.expand_dims(training_labels_x1[:,map_kg[4*branch +3]],1), np.expand_dims(training_labels_x2[:,map_kg[4*branch+3]],1)],axis = 1),axis = 1)
        #             Y_profiling_dict['t_sig_{}'.format(branch)] = labels_sig
        #     else:
        #         for branch in range(8):   
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(training_labels_x1[:,2*branch],1), np.expand_dims(training_labels_x2[:,2*branch],1), np.expand_dims(training_labels_x1[:,2*branch+1],1), np.expand_dims(training_labels_x2[:,2*branch+1],1)],axis = 1),axis = 1)
        #             Y_profiling_dict['s_sig_{}'.format(branch)] = labels_sig
                        
            
        #     validation_data = traces[n_training:n_training + n_validation]
        #     X_validation_dict = {'traces' : validation_data}
            
        #     validation_labels_x1 = labels_target[n_training:n_training + n_validation,:16]
        #     validation_labels_x2 = labels_target[n_training:n_training + n_validation,16:]
            
        #     Y_validation_dict = {}
        #     for byte in range(16):
        #         Y_validation_dict['{}1_{}'.format(target_intermediate,byte)] = get_hot_encode(validation_labels_x1[:,byte] )
        #         Y_validation_dict['{}2_{}'.format(target_intermediate,byte)] = get_hot_encode(validation_labels_x2[:,byte] )
           
        #     if target == 'sbox_input':
        #         for branch in range(4):
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(validation_labels_x1[:,map_kg[4*branch]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch]],1), np.expand_dims(validation_labels_x1[:,map_kg[4*branch +1]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch+1]],1), np.expand_dims(validation_labels_x1[:,map_kg[4*branch +2]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch+2]],1), np.expand_dims(validation_labels_x1[:,map_kg[4*branch +3]],1), np.expand_dims(validation_labels_x2[:,map_kg[4*branch+3]],1)],axis = 1),axis = 1)
        #             Y_validation_dict['t_sig_{}'.format(branch)] = labels_sig
        #     else:
        #         for branch in range(8):   
        #             labels_sig = np.unpackbits(np.concatenate([np.expand_dims(validation_labels_x1[:,2*branch],1), np.expand_dims(validation_labels_x2[:,2*branch],1), np.expand_dims(validation_labels_x1[:,2*branch+1],1), np.expand_dims(validation_labels_x2[:,2*branch+1],1)],axis = 1),axis = 1)
        #             Y_validation_dict['s_sig_{}'.format(branch)] = labels_sig
            
            
        #     training_data , validation_data = tf.data.Dataset.from_tensor_slices((X_profiling_dict ,Y_profiling_dict)), tf.data.Dataset.from_tensor_slices(( X_validation_dict,Y_validation_dict)) 
            
        #     training_data = training_data.shuffle(len(training_data)).batch(batch_size)    
        #     validation_data = validation_data.batch(batch_size)
            

        #     if save_profile :
        #         callbacks = tf.keras.callbacks.ModelCheckpoint(
        #                                     filepath= save_profile +'/'+ model_t +'.h5',
        #                                     save_weights_only=True,
        #                                     monitor=monitor,
        #                                     mode=mode,
        #                                     save_best_only=True)
                
        #         os.makedirs(save_profile, exist_ok=True)
        #         history = model.fit(training_data, batch_size=batch_size, verbose = 'auto', epochs=epochs, validation_data=validation_data,callbacks =callbacks)
        #     else:
        #         print('BEST MODEL IS USUALLY SAVED ON DISK USING A CALLBACK MONITORING THE VAL LOSS. HERE THE MODEL OF THE LAST EPOCH IS CHOSEN (MIGHT NOT BE THE BEST). THE MODELS SIZE ARE ABOUT 500KB...')
        #         history = model.fit(training_data, batch_size=batch_size, verbose = 'auto', epochs=epochs, validation_data=validation_data)
                
        #     if target == 'sbox_output':      
        #         self.model_sbox = model
        #     elif target == 'sbox_input':
        #         self.model_sbox_input = model
        #     else:
        #         print('SCOUBIDOU')            
        return
    def attack(self, attack_dataset: DatasetReader, attack_path) -> KeyGuess: 
       
        cnt_traces = 0
        iterobj = attack_dataset.iter_ntraces(None, max_chunk_size=MAX_CHUNK_SIZE)

        # Amount of traces to be processed
        nchunks = len(iterobj)
        # Allocate memory to store the likelihood of obtain for each
        # byte of the key and for each chunks.
        like = np.zeros([nchunks,16,256])
        pbar = tqdm.tqdm(enumerate(iterobj),total=len(iterobj))
        
        first_bytes = [12,1,6,11]
        second_bytes = [8,13,2,7]
        third_bytes = [4,9,14,3]
        fourth_bytes = [0,5,10,15]
        
   

        for cidx,chunk in pbar:
            # Update counter 
            cnt_traces += chunk['traces'].shape[0]
            ntraces = chunk['traces'].shape[0]


            traces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)      
            traces = traces[:,self.indexes]
            traces = traces[:,140:13*70]
            

            predictions = self.model_inputs.predict(traces,batch_size = 500, verbose= 0)
         
            for byte in first_bytes: 
                plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,byte])
                t = predictions['t_{}'.format(byte)] 
                k_from_t =self.xor_layer([t,plaintexts])
                
                like[cidx,byte] = np.sum(np.log2(k_from_t ),axis = 0) 
        sum_log_like = np.sum(like,axis = 0)  
        value_byte = []
        for byte in first_bytes:
            value_byte.append(get_hot_encode(np.argmax(sum_log_like[byte])).reshape(1,256))

        pbar = tqdm.tqdm(enumerate(iterobj),total=len(iterobj))
        pred_key_trans= np.zeros([nchunks,4,256])
        pred_15_from_12 = np.zeros([nchunks,256])
        for cidx,chunk in pbar:
            cnt_traces += chunk['traces'].shape[0]
            ntraces = chunk['traces'].shape[0]
            
            traces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)
            traces_trans = traces[:,self.indexes_trans]  + self.offset[400:2000]         
            traces_key = traces[:,self.indexes_keys] + self.offset[:1400]               
            predictions = self.model_transitions.predict(traces_trans,batch_size = 500, verbose= 0)
            predictions_15_from_12 = self.model_key.predict(traces_key,batch_size = 500, verbose= 0)
            predictions_key_trans = self.model_key_trans.predict(traces_key,batch_size = 500, verbose= 0)

            count = 0
            for byte in second_bytes:
                key_val = tf.repeat(value_byte[count],ntraces,axis = 0)
                transition = predictions['t_{}'.format(byte)] 
                plaintexts_trans = get_hot_encode(chunk['umsk_plaintext'][:,first_bytes[count]])                
                t_from_tran =self.xor_layer([tf.cast(plaintexts_trans,tf.float64),key_val])
                t_from_tran =self.xor_layer([t_from_tran ,transition])
                plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,byte])  
                k_from_t =self.xor_layer([t_from_tran,plaintexts])
                like[cidx,byte] = np.sum(np.log2(k_from_t ),axis = 0) 
                count+= 1

            count = 0
            for byte in third_bytes:
                transition = predictions['t_{}'.format(byte)] 
                plaintexts_trans = get_hot_encode(chunk['umsk_plaintext'][:,second_bytes[count]])                
                t_from_tran =self.xor_layer([tf.cast(plaintexts_trans,tf.float64),transition])
                plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,byte])  
                k_from_t =self.xor_layer([t_from_tran,plaintexts])
                like[cidx,byte] = np.sum(np.log2(k_from_t ),axis = 0) 
                count+= 1

            count = 0
            for byte in fourth_bytes:
                transition = predictions['t_{}'.format(byte)] 
                plaintexts_trans = get_hot_encode(chunk['umsk_plaintext'][:,third_bytes[count]])                
                t_from_tran =self.xor_layer([tf.cast(plaintexts_trans,tf.float64),transition])
                plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,byte])  
                k_from_t =self.xor_layer([t_from_tran,plaintexts])
                like[cidx,byte] = np.sum(np.log2(k_from_t ),axis = 0) 
                if not (byte == 10 or  byte == 15):
                    key_transition = predictions_key_trans['k_{}'.format(byte)] 
                    k_from_t =self.xor_layer([key_transition,plaintexts])
                    pred_key_trans[cidx,count] = np.sum(np.log2(k_from_t ),axis = 0)
                count+= 1
            transition = predictions_15_from_12['t']
            key_val = tf.repeat(value_byte[0],ntraces,axis =0)      
            plaintexts = get_hot_encode(chunk['umsk_plaintext'][:,15])  
            k_from_tran =self.xor_layer([transition ,plaintexts])
            k_from_tran =self.xor_layer([ k_from_tran  ,key_val])
            pred_15_from_12[cidx] = np.sum(np.log2(k_from_tran),axis = 0) 

        sum_log_like = np.sum(like,axis = 0)  
        count = 0            
        for byte in third_bytes:
            sum_log_like[byte] = np.log2(self.xor_layer([tf.nn.softmax(sum_log_like[byte]).reshape(1,256),tf.nn.softmax(sum_log_like[second_bytes[count]]).reshape(1,256)]))
            count+=1
        count = 0             
        for byte in fourth_bytes:
            if byte ==10 :
                sum_log_like[byte] = np.log2(self.xor_layer([tf.nn.softmax(sum_log_like[byte]).reshape(1,256),2**(sum_log_like[third_bytes[count]]).reshape(1,256)]))
            
            elif byte == 15:
                sum_log_like[byte] = np.log2(self.xor_layer([tf.nn.softmax(sum_log_like[byte]).reshape(1,256),2**(sum_log_like[third_bytes[count]]).reshape(1,256)]) * tf.nn.softmax(np.sum( pred_15_from_12,axis = 0)))
            else:
                pred_from_key_trans = tf.nn.softmax(np.sum( pred_key_trans[:,count],axis = 0)).reshape(1,256)
                if byte == 0:
                     pred_from_key_trans = self.xor_layer([pred_from_key_trans,tf.nn.softmax(sum_log_like[13]).reshape(1,256)])
                else:
                     pred_from_key_trans = self.xor_layer([pred_from_key_trans,2**(sum_log_like[14]).reshape(1,256)])
                sum_log_like[byte] = np.log2(self.xor_layer([tf.nn.softmax(sum_log_like[byte]).reshape(1,256),2**(sum_log_like[third_bytes[count]]).reshape(1,256)]) * pred_from_key_trans)
            count+=1


            # Create key guess object. Here, we give probabilities for each pf the
            # 16-bytes of the unmasked-key. See key_guess.py for more info.  
        kg = KeyGuess(
                    [list(range(8*i,8*(i+1))) for i in range(16)],
                    (-sum_log_like).tolist()
                    )    

        return kg 

    # DO NOT MODIFY! 
    def save_profile(self, profile_dir: str):
        
        return


    def load_profile(self, profile_dir: str):
        
        self.model_inputs = self.make_model_sbox_input(profile_dir)
        self.model_transitions = self.make_model_sbox_input_transitions(profile_dir)
        self.model_key = self.make_model_keys(profile_dir) 
        self.model_key_trans = self.make_model_keys_trans(profile_dir)         
    ## Create structures and load weights from the saved files.
    def make_model_keys(self, profile_dir: str):
        structure_model_key = model_single_task_key(labels_mask = True)
        model_file = '.'+ profile_dir + '/model_key{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        
        new_input = tf.keras.layers.Input((200*7),name = 'traces')   
        new_model =structure_model_key(new_input)
        outputs= {}
        x = XorLayer(name = 'xor')([new_model['t1'],new_model['t2_before_soft']])  
        outputs['t'] = tf.keras.layers.Softmax(name = 't')(x)
        model = tf.keras.models.Model(inputs = new_input,outputs= outputs)
        model.load_weights(model_file)
        return  model
 
    def make_model_sbox_input_transitions(self, profile_dir: str):
        structure_model_sbox_input_transitions = model_multi_task_sbox_input_transitions(labels_mask = True)               
        new_input = tf.keras.layers.Input((200*8,),name = 'traces')   
        new_model = structure_model_sbox_input_transitions(new_input)
        outputs= {}
        map_kg = np.array([
               15,3,7,13
              ])     
        for byte in map_kg:
            x = self.xor_layer([new_model['t1_{}'.format(byte)], new_model['t2_before_soft_{}'.format(byte)]])
            outputs['t_{}'.format(byte)] = tf.keras.layers.Softmax(name = 't_{}'.format(byte))(x)
        model_3 = tf.keras.models.Model(inputs = new_input,outputs= outputs) 
        model_file = '.'+ profile_dir + '/model_sbox_input_trans_7_3_15{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        model_3.load_weights(model_file)
        
        structure_2 = model_multi_task_sbox_input_transitions(labels_mask = True)               
        new_input_2 = tf.keras.layers.Input((200*8,),name = 'traces')   
        new_model_2 = structure_2(new_input_2)
        outputs= {}
        map_kg = np.array([
               10,14,2
              ])     
        for byte in map_kg:
            x = self.xor_layer([new_model_2['t1_{}'.format(byte)], new_model_2['t2_before_soft_{}'.format(byte)]])
            outputs['t_{}'.format(byte)] = tf.keras.layers.Softmax(name = 't_{}'.format(byte))(x)
        model_2 = tf.keras.models.Model(inputs = new_input_2,outputs= outputs) 
        model_file = '.'+ profile_dir + '/model_t_column_2{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        model_2.load_weights(model_file)


      
        structure_3 = model_multi_task_sbox_input_column(0,labels_mask = False)               
        new_input_3 = tf.keras.layers.Input((200*8,),name = 'traces')   
        new_model_3 = structure_3(new_input_3)
        outputs= {}
        map_kg = np.array([
               0,4,8
              ])     
        for byte in map_kg:
            x = self.xor_layer([new_model_3['t1_{}'.format(byte)], new_model_3['t2_before_soft_{}'.format(byte)]])
            outputs['t_{}'.format(byte)] = tf.keras.layers.Softmax(name = 't_{}'.format(byte))(x)
        model_0 = tf.keras.models.Model(inputs = new_input_3,outputs= outputs) 
        model_file = '.'+ profile_dir + '/model_t_column_0{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        model_0.load_weights(model_file)

        structure_4 = model_multi_task_sbox_input_column(1,labels_mask = False)               
        new_input_4 = tf.keras.layers.Input((200*8,),name = 'traces')   
        new_model_4 = structure_4(new_input_4)
        outputs= {}
        map_kg = np.array([
               5,9,13
              ])     
        for byte in map_kg:
            x = self.xor_layer([new_model_4['t1_{}'.format(byte)], new_model_4['t2_before_soft_{}'.format(byte)]])
            outputs['t_{}'.format(byte)] = tf.keras.layers.Softmax(name = 't_{}'.format(byte))(x)
        model_1 = tf.keras.models.Model(inputs = new_input_4,outputs= outputs) 
        model_file = '.'+ profile_dir + '/model_t_column_1{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        model_1.load_weights(model_file)

        structure_5 = model_multi_task_sbox_input_column(2,labels_mask = False)               
        new_input_5 = tf.keras.layers.Input((200*8,),name = 'traces')   
        new_model_5 = structure_5(new_input_5)
        outputs= {}
        map_kg = np.array([
               10,14,2
              ])     
        for byte in map_kg:
            x = self.xor_layer([new_model_5['t1_{}'.format(byte)], new_model_5['t2_before_soft_{}'.format(byte)]])
            outputs['t_{}'.format(byte)] = tf.keras.layers.Softmax(name = 't_{}'.format(byte))(x)
        model_2_10 = tf.keras.models.Model(inputs = new_input_5,outputs= outputs) 
        model_file = '.'+ profile_dir + '/model_t_column_2_only_10{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        model_2_10.load_weights(model_file)

        
        new_input = tf.keras.layers.Input((200*8,),name = 'traces')
        outputs = {}
        model_0 = model_0(new_input)
        model_1 = model_1(new_input)
        model_2 = model_2(new_input)
        model_2_10 = model_2_10(new_input)
        model_3 = model_3(new_input)
        
        for k , v in model_0.items():
            outputs[k] = v
        for k , v in model_1.items():
            if k == 't_13':
                continue
            outputs[k] = v       
        for k , v in model_2.items():
            if k != 't_10':               
                outputs[k] = v   
        for k , v in model_2_10.items():
            if k == 't_10':
                outputs[k] = v   
        for k , v in model_3.items():
            outputs[k] = v        
        
        model = tf.keras.models.Model(inputs = new_input,outputs= outputs) 
        return  model

   

    def make_model_sbox_input(self, profile_dir: str):
        structure_model_sbox_input = model_multi_task_sbox_input(labels_mask = False)
        model_file = '.'+ profile_dir + '/model_sbox_input{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        structure_model_sbox_input.load_weights(model_file,by_name = True)
        return  structure_model_sbox_input
    def make_model_keys_trans(self, profile_dir: str):
        structure_model_key = model_multi_task_key_transitions(labels_mask = False)
        model_file = '.'+ profile_dir + '/model_key_trans{}.h5'.format('' if self.attack_case == 'S6_d2' else '_A7_d2')
        
        new_input = tf.keras.layers.Input((200*7),name = 'traces')   
        new_model =structure_model_key(new_input)
        outputs= {}
        map_kg = np.array([
                      0,5,15
                      ])     
        for byte in map_kg:
            x = XorLayer(name = 'xor_{}'.format(byte))([new_model['k1_{}'.format(byte)], new_model['k2_before_soft_{}'.format(byte)]])
            outputs['k_{}'.format(byte)] = tf.keras.layers.Softmax(name = 'k_{}'.format(byte))(x)
        model = tf.keras.models.Model(inputs = new_input,outputs= outputs)
        model.load_weights(model_file)
        return  model
   

    # From a byte id, return the location in the matrix representation of the
    # state. The location is representation as a pair of indexes, one for the
    # row, and one for the column. 
    def id2loc(self,bid):
        colid = bid // 4
        rowid = bid % 4
        return (rowid,colid)

    # Return the sharing part of the TapSignal instance (see TapSignal definition in tap_config.py for more details).
    def strshi(self, shi):
        return 'r' if shi == None else shi

    # Return the string id of a single byte of the state after the Sboxes. In
    # particular, bidx is the index of the byte (in [0,15]) and shi is the
    # index of the share (in [0,1]).
    def tapname_byte_fromSB(self, bidx,shi, round_id=0):
        # Fetch byte location for bidx
        (rid, cid) = self.id2loc(bidx) 
        # Clock index
        # Here:
        # - the +1 is used to take into account the first cycle of the execution, during 
        # which the KeySchedule of the first round starts. 
        # - the +6 is used to take into account the Sbox latency.  
        c2t = cid + 6 + 1 + 10*round_id 
        # Return the indentifier. 
        tapsig_yi = "B_fromSB__{}.{}.{}.0:7.raw".format(rid,c2t,self.strshi(shi))
        return tapsig_yi

