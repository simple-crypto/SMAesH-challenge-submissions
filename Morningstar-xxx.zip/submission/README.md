# SMAesH-challenge


###############################################################

I provide the profiling setup only for information purposes. 

I didn't tested if the training is the same, even though it should be.

The placeholders warning are normal and there is no way around unfortunately. It comes from tensorflow 2.13.