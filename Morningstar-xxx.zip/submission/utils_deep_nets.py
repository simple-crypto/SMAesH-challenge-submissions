# -*- coding: utf-8 -*-
"""
Created on Mon May 15 09:14:50 2023

@author: martho
"""

import os
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Reshape , BatchNormalization, Multiply , Dense , Concatenate, Softmax , Conv1D, AveragePooling1D, Flatten , Activation, Subtract
from tensorflow.keras.optimizers import Adam
import tensorflow.experimental.numpy as tnp
import numpy as np

tnp.experimental_enable_numpy_behavior()
tf.keras.backend.set_floatx('float64')
tf.config.experimental.enable_tensor_float_32_execution(False)
seed = 7


tf.random.set_seed(seed)
np.random.seed(seed)
os.environ['PYTHONHASHSEED'] = str(seed)
os.environ['TF_DETERMINISTIC_OPS'] = '1'
os.environ['TF_CUDNN_DETERMINISTIC'] = '1'        


class XorLayer(tf.keras.layers.Layer):
  def __init__(self,classes =256 ,name = ''):
    super(XorLayer, self).__init__(name = name)
    all_maps = np.load('xor_mapping.npy')
    mapping1 = []
    mapping2 = []
    for classe in range(classes):
        mapped = np.where(all_maps[classe] == 1)
        mapping1.append(mapped[0])
        mapping2.append(mapped[1])
    self.mapping1 = np.array(mapping1)
    self.mapping2 = np.array(mapping2)
    self.classes = classes
    
  def call(self, inputs):  
 
    pred1 = inputs[0]
    pred2 = tnp.asarray(inputs[1],dtype = tf.float64)
    p1 = pred1
    p2 = pred2[:,self.mapping2]
    res = tf.einsum('ij,ijk->ik',p1,p2)
    return res

    def get_config(self):
        config = {'mapping':self.mapping}
        base_config = super(XorLayer,self).get_config()
        return dict(list(base_config.items()) + list(config.items()))######################################
class SharedWeightsDenseLayer(tf.keras.layers.Layer):
    def __init__(self, input_dim=1,units = 1, shares = 16,name = '',activation = True,precision = 'float32',trainable = True):
        if name == '':
            name = 'SharedWeightsDenseLayer_'+str(np.random.randint(0,high = 99999))
        super(SharedWeightsDenseLayer, self).__init__(name = name )
        self.w = self.add_weight(shape=(input_dim,units), dtype=precision,
                                  trainable=trainable,name = 'weights'+name,initializer=tf.keras.initializers.RandomUniform(seed=7)
                                  
        )
        self.b = self.add_weight(shape=(units,shares), dtype=precision,
                                  trainable=trainable,name = 'biais'+name,initializer=tf.keras.initializers.RandomUniform(seed=7)
                                  
        )
        self.input_dim = input_dim
        self.shares = shares
        self.activation = activation
        self.precision = tf.float64 if precision == 'float64' else tf.float32

    
        
    def call(self, inputs):
        x = tf.einsum('ijk, jf -> ifk',tf.cast(inputs,self.precision),self.w)    
        if self.activation:
            return tf.keras.activations.selu( x + self.b)
        else:
            return  x + self.b      
        

def model_single_task_key(labels_mask = False, learning_rate=0.001, classes=256 , name ='',summary = True):
    
    inputs_dict = {}
    traces  = Input(shape = (200*7,) ,name = 'traces')
    inputs_dict['traces'] =  traces
    traces = Reshape((200,7))(traces)
    
    
    # traces_x1 = cnn_core(traces)    
    # traces_x2 = cnn_core(traces)

    traces = SharedWeightsDenseLayer(input_dim = traces.shape[1],units = 35,shares = traces.shape[-1],precision = 'float64')(traces)        
    traces = BatchNormalization(axis = 1)(traces)    
    traces = Flatten()(traces)        

    outputs = {} 
    
    branch_block_x1 = Dense(8,activation = 'selu')(traces)
    branch_block_x1 = BatchNormalization()(branch_block_x1)
    branch_block_x1 = Dense(256)(branch_block_x1)
    outputs['t1'] = Softmax(name = 't1')(branch_block_x1)
    
    branch_block_x2 = Dense(8,activation = 'selu')(traces)
    branch_block_x2 = BatchNormalization()(branch_block_x2)
    branch_block_x2 = Dense(256)(branch_block_x2)
    outputs['t2_before_soft'] = branch_block_x2
    outputs['t2'] = Softmax(name = 't2')(branch_block_x2)
    if not labels_mask:
        x = XorLayer()([branch_block_x1,branch_block_x2])
        outputs['output'] = Softmax(name = 'output')(x)

        


            # k = branch_block_k[:,8*block:8*(block+1),part]
            # k = Activation('sigmoid',dtype = tf.float64)(k)
            # outputs['t_sig_{}'.format(map_kg[4*part + block])] = k
    # all_branches = Concatenate(axis = 2)(input_to_output)
    
    # for byte in range(16):
    #     real_byte = map_kg[byte]
            
    #     x1 = Softmax(name = 'output_t1_{}'.format(real_byte),dtype = tf.float64)(branch_output[:,:,2*byte])

    #     x2 = Softmax(name = 'output_t2_{}'.format(real_byte),dtype = tf.float64)(branch_output[:,:,2*byte+1])  
    #     outputs['t_{}'.format(real_byte)] = XorLayer(name = 'x_{}'.format(byte))([x1,x2])

            #outputs['x_{}'.format(byte)] = XorLayer(name = 'x_{}'.format(byte))([x1,x2])       
    losses = {}   
    metrics = {}
    weights = {}
    for k , v in outputs.items():
        losses[k] = 'categorical_crossentropy'
        metrics[k] = 'accuracy'
        weights[k] = 100 if not labels_mask else 1

    model = Model(inputs = inputs_dict,outputs = outputs,name='cnn_multi_task')
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(loss=losses, optimizer=optimizer, metrics=metrics,loss_weights = weights)
    if summary:
        model.summary()
    return model  

def get_hot_encode(label_set,classes = 256):    
    return tf.one_hot(label_set,depth = classes,dtype = tf.uint8)
### Multi-Task Models

def model_multi_task_key_transitions( learning_rate=0.001, classes=256,labels_mask = False , name ='',summary = False):
    
    inputs_dict = {}
    
    traces  = Input(shape = (200*7,) ,name = 'traces')
    inputs_dict['traces'] =    traces
    traces = Reshape((200,7))(traces)



    traces = SharedWeightsDenseLayer(input_dim = traces.shape[1],units = 35,shares = traces.shape[-1],precision = 'float64')(traces)        
    traces = BatchNormalization(axis = 1)(traces)         
    traces = Flatten()(traces)

    outputs = {} 
    map_kg = np.array([
               0,5,10,15,4, 9, 14, 3, 8, 13, 2, 7
              ])     
    real_target = np.array([0,5,10,15])
    col_byte = 0

   
    branch_block_x1 = dense_core_shared(traces,non_shared_block = 1, shared_block = 1,branches = 4,units = 8, output_units = 256 ,split = False,precision = 'float64',trainable =True)
    branch_block_x2 = dense_core_shared(traces,non_shared_block = 1, shared_block = 1,branches = 4,units = 8, output_units = 256 ,split = False,precision = 'float64',trainable =True)


    for byte in range(4):
        x1 = branch_block_x1[:,:,byte]       
        x2 = branch_block_x2[:,:,byte]
        outputs['k2_{}'.format(real_target[byte])] = Softmax(name = 'k2_{}'.format(real_target[byte]))(x2)
        if not labels_mask:
            outputs['k2_before_soft_{}'.format(real_target[byte])] =x2
        x1 = Softmax(name = 'k1_{}'.format(real_target[byte]))(x1)
        outputs['k1_{}'.format(real_target[byte])] = x1

         

        
            #outputs['hw_t_{}'.format(map_kg[4*branch + block])] = hw_x
    # all_branches = Concatenate(axis = 2)(input_to_output)
    
    # for byte in range(16):
    #     real_byte = map_kg[byte]
            
    #     x1 = Softmax(name = 'output_t1_{}'.format(real_byte),dtype = tf.float64)(branch_output[:,:,2*byte])

    #     x2 = Softmax(name = 'output_t2_{}'.format(real_byte),dtype = tf.float64)(branch_output[:,:,2*byte+1])  
    #     outputs['t_{}'.format(real_byte)] = XorLayer(name = 'x_{}'.format(byte))([x1,x2])

            #outputs['x_{}'.format(byte)] = XorLayer(name = 'x_{}'.format(byte))([x1,x2])       
    losses = {}   
    metrics = {}
    weights = {}
    for k , v in outputs.items():
        if not 'sig' in k:
            losses[k] = 'categorical_crossentropy'
            metrics[k] = 'accuracy'
            weights[k] = 100
        else:
            losses[k] = 'binary_crossentropy'
            metrics[k] = 'binary_accuracy'
            weights[k] = 100            

    model = Model(inputs = inputs_dict,outputs = outputs,name='cnn_multi_task')
    optimizer = Adam(learning_rate=learning_rate) 
    model.compile(loss=losses, optimizer=optimizer, metrics=metrics,loss_weights = weights)
    if summary:
        model.summary()
    return model   


def model_multi_task_sbox_input_transitions( learning_rate=0.001, classes=256,labels_mask = False,second_training = False , name ='',summary = False):
    
    inputs_dict = {}
    
    traces  = Input(shape = (200*8,) ,name = 'traces')
    inputs_dict['traces'] =    traces
    traces = Reshape((200,8))(traces)
    concat_list = []
    for column in range(3):
        concat_list.append(Reshape((200*6,1))(traces[:,:,column:column+6]))
    traces = Concatenate(axis = 2)(concat_list)


    #traces = cnn_core(traces)
    traces = SharedWeightsDenseLayer(input_dim = traces.shape[1],units = 35,shares = traces.shape[-1],precision = 'float64')(traces)     
    traces = BatchNormalization(axis = 1)(traces)
    #traces_x1 = Flatten()(traces_x1)     


    #traces_x2 = Flatten()(traces_x2)     
  

    #traces = SharedWeightsDenseLayer(input_dim = traces.shape[1],units = 35,shares = traces.shape[-1],precision = 'float64')(traces)        
    #traces = BatchNormalization(axis = 1)(traces)            

    outputs = {} 
    map_kg = np.array([
               0,5,10,15,4, 9, 14, 3, 8, 13, 2, 7
              ])     
    col_byte = 0
    input_to_output_x1 = []   
    input_to_output_x2 = []
    input_to_output_x = []  
   
    branch_block_x1 = dense_core_shared_columns(traces)
    branch_block_x2 = dense_core_shared_columns(traces)

    for byte in range(12):
        x1 = branch_block_x1[:,:,byte]       
        x2 = branch_block_x2[:,:,byte]
      
    
        x1 = Softmax(name = 't1_{}'.format(map_kg[byte]))(x1)
        if labels_mask:
            outputs['t1_{}'.format(map_kg[byte])] = x1
        
        
        
        if labels_mask :
            outputs['t2_before_soft_{}'.format(map_kg[byte])] = x2 
            x2 = Softmax(name = 't2_{}'.format(map_kg[byte]))(x2)
            outputs['t2_{}'.format(map_kg[byte])] = x2   
        if (not  labels_mask) :
            x = XorLayer(name = 'x_{}'.format(map_kg[byte]))([x1,x2])
            outputs['t_{}'.format(map_kg[byte])] = Softmax(name = 't_{}'.format(map_kg[byte]))(x)   
        
            #outputs['hw_t_{}'.format(map_kg[4*branch + block])] = hw_x
    # all_branches = Concatenate(axis = 2)(input_to_output)
    
    # for byte in range(16):
    #     real_byte = map_kg[byte]
            
    #     x1 = Softmax(name = 'output_t1_{}'.format(real_byte),dtype = tf.float64)(branch_output[:,:,2*byte])

    #     x2 = Softmax(name = 'output_t2_{}'.format(real_byte),dtype = tf.float64)(branch_output[:,:,2*byte+1])  
    #     outputs['t_{}'.format(real_byte)] = XorLayer(name = 'x_{}'.format(byte))([x1,x2])

            #outputs['x_{}'.format(byte)] = XorLayer(name = 'x_{}'.format(byte))([x1,x2])       
    losses = {}   
    metrics = {}
    weights = {}
    for k , v in outputs.items():
        if not 'sig' in k:
            losses[k] = 'categorical_crossentropy'
            metrics[k] = 'accuracy'
            weights[k] = 1
        else:
            losses[k] = 'binary_crossentropy'
            metrics[k] = 'binary_accuracy'
            weights[k] = 1       

    model = Model(inputs = inputs_dict,outputs = outputs,name='cnn_multi_task')
    optimizer = Adam(learning_rate=learning_rate) 
    model.compile(loss=losses, optimizer=optimizer, metrics=metrics,loss_weights = weights)
    if summary:
        model.summary()
    return model   

def model_multi_task_sbox_input( learning_rate=0.001, classes=256,labels_mask = False , name ='',summary = False):
    map_kg = np.array([
              0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11
              ])        
    inputs_dict = {}
    
    
    traces  = Input(shape = (70*11,) ,name = 'traces')
    inputs_dict['traces'] =    traces
    traces = Reshape((70,11))(traces)
    
    traces_x1 = SharedWeightsDenseLayer(input_dim = traces.shape[1],units = 35,shares = traces.shape[-1],precision = 'float64')(traces)        
    traces_x1 = BatchNormalization(axis = 1)(traces_x1)
    
    traces_x2 = SharedWeightsDenseLayer(input_dim = traces.shape[1],units = 35,shares = traces.shape[-1],precision = 'float64')(traces)        
    traces_x2 = BatchNormalization(axis = 1)(traces_x2)  

    #traces = SharedWeightsDenseLayer(input_dim = traces.shape[1],units = 35,shares = traces.shape[-1],precision = 'float64')(traces)        
    #traces = BatchNormalization(axis = 1)(traces)            

    outputs = {} 
    map_kg = np.array([
              0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11
              ])     
    col_byte = 0
    input_to_output_x1 = []   
    input_to_output_x2 = []
    input_to_output_x = []  

    branch_block_x1 = dense_core_shared(Flatten()(traces_x1),non_shared_block = 1,shared_block =  1, units = 8,branches = 4, output_units = 32,split = False,precision = 'float64',trainable = True)  
    branch_block_x2 = dense_core_shared(Flatten()(traces_x2),non_shared_block = 1,shared_block =  1, units = 8,branches = 4, output_units = 32,split = False,precision = 'float64',trainable = True)  
    for branch in range(4):
        for block in range(4):
            input_to_output_x1.append(tf.expand_dims(branch_block_x1[:,8*block:8*(block+1),branch],2))
            input_to_output_x2.append(tf.expand_dims(branch_block_x2[:,8*block:8*(block+1),branch],2))

    branch_block_x1 = Concatenate(axis = 2)(input_to_output_x1)
    branch_block_x2 = Concatenate(axis = 2)(input_to_output_x2)

    branch_block_x1 = SharedWeightsDenseLayer(input_dim = branch_block_x1.shape[1],units = 256,shares = branch_block_x1.shape[-1],precision = 'float64',activation = False , trainable =True )(branch_block_x1)     
    branch_block_x2 = SharedWeightsDenseLayer(input_dim = branch_block_x2.shape[1],units = 256,shares = branch_block_x2.shape[-1],precision = 'float64',activation = False, trainable =True )(branch_block_x2)     
    
    list_cr = []
    
    for block in range(16):
        
        x1 = branch_block_x1[:,:,block]
        x1 = Softmax(name = 't1_{}'.format(map_kg[block]))(x1)
        outputs['t1_{}'.format(map_kg[block])] = x1
        if labels_mask:
            outputs['t1_{}'.format(map_kg[block])] = x1
        
        x2 = branch_block_x2[:,:,block]
        
        if labels_mask:
            outputs['t2_before_soft_{}'.format(map_kg[block])] = x2 
            x2 = Softmax(name = 't2_{}'.format(map_kg[block]))(x2)
            outputs['t2_{}'.format(map_kg[block])] = x2   
        if not labels_mask:
            x = XorLayer(name = 'x_{}'.format(map_kg[block]))([x1,x2])
            x2 = Softmax(name = 't2_{}'.format(map_kg[block]))(x2)
            outputs['t2_{}'.format(map_kg[block])]  =x2
            outputs['t_{}'.format(map_kg[block])] = Softmax(name = 't_{}'.format(map_kg[block]))(x)                
    #     x1 = Softmax(name = 'output_t1_{}'.format(real_byte),dtype = tf.float64)(branch_output[:,:,2*byte])

    #     x2 = Softmax(name = 'output_t2_{}'.format(real_byte),dtype = tf.float64)(branch_output[:,:,2*byte+1])  
    #     outputs['t_{}'.format(real_byte)] = XorLayer(name = 'x_{}'.format(byte))([x1,x2])

            #outputs['x_{}'.format(byte)] = XorLayer(name = 'x_{}'.format(byte))([x1,x2])       
    losses = {}   
    metrics = {}
    weights = {}
    for k , v in outputs.items():
        losses[k] = 'categorical_crossentropy'
        metrics[k] = 'accuracy'
        weights[k] = 100
       

    model = Model(inputs = inputs_dict,outputs = outputs,name='sbox_input_model')
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(loss=losses, optimizer=optimizer, metrics=metrics,loss_weights = weights)
     
    
    return model   
def model_multi_task_sbox_input_column( target,learning_rate=0.001, classes=256,labels_mask = False,second_training = False , name ='',summary = False):
    
    inputs_dict = {}
    
    traces  = Input(shape = (200*8,) ,name = 'traces')
    inputs_dict['traces'] =    traces
    traces = Reshape((200,8))(traces)
    concat_list = []
    for column in range(3):
        concat_list.append(Reshape((200*6,1))(traces[:,:,column:column+6]))
    traces = Concatenate(axis = 2)(concat_list)
    traces = SharedWeightsDenseLayer(input_dim = traces.shape[1],units = 35,shares = traces.shape[-1],precision = 'float64')(traces)     
    traces = BatchNormalization(axis = 1)(traces)
    

    outputs = {} 
    map_kg = np.array([
               0,5,10,15,4, 9, 14, 3, 8, 13, 2, 7
              ])
    if target == 0:     
        real_target = np.array([0,4, 8])
    if target == 1:     
        real_target = np.array([5,9, 13])
    if target == 2:     
        real_target = np.array([10,14, 2])
    if target == 3:     
        real_target = np.array([15,3, 7])
    input_to_output_x1 = []   
    input_to_output_x2 = []
    input_to_output_x = []  
   
    branch_block_x1 = dense_core_shared(traces,non_shared_block = 1, shared_block = 1,branches = 3,units = 8, output_units = 256 ,split = True,precision = 'float64',trainable =True)
    branch_block_x2 = dense_core_shared(traces,non_shared_block = 1, shared_block = 1,branches = 3,units = 8, output_units = 256 ,split = True,precision = 'float64',trainable =True)


    for byte in range(3):
        x1 = branch_block_x1[:,:,byte]       
        x2 = branch_block_x2[:,:,byte]
      
    
        x1 = Softmax(name = 't1_{}'.format(real_target[byte]))(x1)
        outputs['t1_{}'.format(real_target[byte])] = x1
        
        
        
        if not labels_mask :
            outputs['t2_before_soft_{}'.format(real_target[byte])] = x2 
        x2 = Softmax(name = 't2_{}'.format(real_target[byte]))(x2)
        outputs['t2_{}'.format(real_target[byte])] = x2   

    
    losses = {}   
    metrics = {}
    weights = {}
    for k , v in outputs.items():
        if not 'sig' in k:
            losses[k] = 'categorical_crossentropy'
            metrics[k] = 'accuracy'
            weights[k] = 1
        else:
            losses[k] = 'binary_crossentropy'
            metrics[k] = 'binary_accuracy'
            weights[k] = 1       

    model = Model(inputs = inputs_dict,outputs = outputs,name='cnn_multi_task')
    optimizer = Adam(learning_rate=learning_rate) 
    model.compile(loss=losses, optimizer=optimizer, metrics=metrics,loss_weights = weights)
    if summary:
        model.summary()
    return model   
######################## ARCHITECTURE BUILDING ################################

def dense_core_shared_columns(inputs_core,precision = 'float64',trainable = True):
    non_shared_branch = []
    dense_column =  Dense(32,activation ='selu',kernel_initializer=tf.keras.initializers.RandomUniform(seed=7))
    
    for column in range(inputs_core.shape[-1]):
        x = inputs_core
        
        # for block in range(non_shared_block):
        x = dense_column(x[:,:,column])
        x = BatchNormalization()(x)
        x = Reshape((8,4))(x)
        
        non_shared_branch.append(x)
    x = Concatenate(axis = 2)(non_shared_branch)

    output_layer = SharedWeightsDenseLayer(input_dim = x.shape[1],units = 256,activation = False,shares = inputs_core.shape[-1]*4,precision = precision)(x)   

    return output_layer

def dense_core_shared_columns_2(inputs_core,precision = 'float64',trainable = True):
    non_shared_branch = []
    dense_column =  Dense(16,activation ='selu',kernel_initializer=tf.keras.initializers.RandomUniform(seed=7))
    
    dense_column.trainable = False 
    for column in range(inputs_core.shape[-1]):
        x = inputs_core
        
        # for block in range(non_shared_block):
        x = dense_column(x[:,:,column])
        x = BatchNormalization()(x,training = False)
        x = Reshape((8,2))(x)
        
        non_shared_branch.append(x)
    x = Concatenate(axis = 2)(non_shared_branch)

    output_layer = SharedWeightsDenseLayer(input_dim = x.shape[1],units = 256,activation = False,shares = inputs_core.shape[-1]*2,precision = precision,trainable = False)(x)   

    return output_layer

def dense_core_shared(inputs_core, shared_block = 1,non_shared_block = 1, units = 64, branches = 16,output_units = 32,precision = 'float32',split = False,trainable = True):
    non_shared_branch = []
    if non_shared_block > 0:
        for branch in range(branches):
            x = inputs_core
            # for block in range(non_shared_block):
            x = Dense(units,activation ='selu',kernel_initializer=tf.keras.initializers.RandomUniform(seed=7))(x[:,:,branch] if split else x)
            if not trainable:
                x.trainable = False
            x = BatchNormalization()(x, training = trainable)
            non_shared_branch.append(tf.expand_dims(x,2))
        x = Concatenate(axis = 2)(non_shared_branch)
        mid_branch = x
    else:
        x = inputs_core

    for block in range(shared_block):
        x = SharedWeightsDenseLayer(input_dim = x.shape[1],units = units,shares = branches,trainable = trainable)(x)        
        x = BatchNormalization(axis = 1)(x)
    output_layer = SharedWeightsDenseLayer(input_dim = x.shape[1],units = output_units,activation = False,shares = branches,precision = precision,trainable = trainable)(x)   

    return output_layer