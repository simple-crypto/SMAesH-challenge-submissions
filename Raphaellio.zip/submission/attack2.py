from dataclasses import dataclass
import json
import sys
import os
import pickle
from typing import List, Set, Dict
import matplotlib.pyplot as plt
from dataset import DatasetReader
from key_guess import KeyGuess

#### Custom import
import numpy as np
from tap_config import TAP_CONFIG, TapConfig, TapSignal
import scalib.metrics
import scalib.modeling
import scalib.attacks
import aeshpc_32bit_d2_lib as plib
import tqdm
import msgpack
import msgpack_numpy
msgpack_numpy.patch(allow_pickle=False)
import eval_utils

import matplotlib.pyplot as plt

from multiprocessing import Pool

from concurrent.futures import ThreadPoolExecutor
from sasca_utils import GRAPH, NAMES


# Maximum amount of a chunk. The dataset is read by 
# small part depicted as 'chunks', and this parameter set 
# the maximum size of each chunk. 
MAX_CHUNK_SIZE=int(2**10)
# Amount of traces used for the SNR computation (POIs identification) 
NT_PROF_SNR = 500000
# Amount of traces used for the creation of the templates.
NT_PROF_LDA = None
# Apply a centering process on each traces (in order to reduce any DC levels)
centered = True

class Attack:
    """Implementation of the proposed attack.

    The sequence of method calls shall be the following during submission test:
    - for profiling: __init__ -> profile -> save_profile
    - for attack: __init__ -> load_profile -> attack

    The __main__ of this script can perform both profiling and evaluation at
    once, avoiding the need for on-disk data storage:
    __init__ -> profile -> attack -> attack -> ...
    """
    def __init__(self, attack_case: str):
        if attack_case not in ('A7_d2',):
            raise NotImplemented('attack case not implemented')
        self.attack_case = attack_case
        # To be completed.
        # Map to map the location of the sbox input to the ouput sbox
        self.map_in2out_SB = [0,13,10,7,4,1,14,11,8,5,2,15,12,9,6,3]

    def profile(self, profile_datasets: List[DatasetReader]):
        # To be completed.
        # Run here the profiling, and store the result in attributes of self.
        # `profile_datasets` contains all the profiling datastets.
        #
        # Short intro on DatasetReader (see dataset.py for more details):
        # you can iterate on a DatasetReader, which iterates over parts of the
        # dataset (this is linked to the dataset being sharded in multiple
        # files).
        # Each iterm of the iterator is a Dict[str, np.ndarray], and the keys
        # are the fields of the dataset ('traces', 'seed', 'umsk_plaintext', ...).
        # The values are numpy arrays, whose first dimension is the multiple
        # traces in the chunk, and the remaining dimentions are field-specific
        # (e.g. for trace it is the lenght of the trace, for key and plaintext
        # it is 16).
        # If you want to use only a part of a dataset, see the method
        # DatasetReader.iter_ntraces(max_ntraces=..., start_trace=...)

        # As required, we end the function by setting the value of the variable 'self.profiled_model'.
        with open("profiling.pkl", 'rb') as file:
            self.profiled_model = pickle.load(file)

    def attack(self, attack_dataset: DatasetReader) -> KeyGuess:
        # To be completed.
        # attack_dataset is a DatasetReader (see comments in `profile`) with a
        # reduced set of fields (only trace and plaintext).
        # Return a KeyGuess (see key_guess.py)
        
        # Here, it is assumed that load_profile has been executed and that
        # the model can be accessed at self.profiled_model.
        return self.attack_sasca(attack_dataset)

    # DO NOT MODIFY! 
    def save_profile(self, profile_dir: str):
        # Save the result of profiling. You can write any file in the directory
        # `profile_dir`.
        # You can use any file format.
        with open(os.path.join(profile_dir, 'profile_data_sasca.pkl'), 'wb') as f:
            pickle.dump(self.profiled_model,f)

    # DO NOT MODIFY! 
    def load_profile(self, profile_dir: str):
        # Load the result of profiling, as saved by `save_profile`.
        with open(os.path.join(profile_dir, 'profile_data_sasca.pkl'), 'rb') as f:
            self.profiled_model = pickle.load(f)

    # From a byte id, return the location in the matrix representation of the
    # state. The location is representation as a pair of indexes, one for the
    # row, and one for the column. 
    def id2loc(self,bid):
        colid = bid // 4
        rowid = bid % 4
        return (rowid,colid)

    # Return the sharing part of the TapSignal instance (see TapSignal definition in tap_config.py for more details).
    def strshi(self, shi):
        return 'r' if shi == None else shi

    # Return the string id of a single byte of the state after the Sboxes. In
    # particular, bidx is the index of the byte (in [0,15]) and shi is the
    # index of the share (in [0,1]).
    def tapname_byte_fromSB(self, bidx,shi, round_id=0):
        # Fetch byte location for bidx
        (rid, cid) = self.id2loc(bidx) 
        # Clock index
        # Here:
        # - the +1 is used to take into account the first cycle of the execution, during 
        # which the KeySchedule of the first round starts. 
        # - the +6 is used to take into account the Sbox latency.  
        c2t = cid + 1 + 6 + 10*round_id
        # Return the indentifier. 
        tapsig_yi = "B_fromSB__{}.{}.{}.0:7.raw".format(rid,c2t,self.strshi(shi))
        return tapsig_yi

    # This function is the practical profiling method of the example package. 
    def profile_sasca(self, profile_datasets: List[DatasetReader]):
        
        return 

    # This function is the practical implementation of the attack of the example submission package. 
    def attack_sasca(self, attack_dataset: DatasetReader) -> KeyGuess: 
        # Import the SASCA graph.
        import sasca_utils 
        

        # Recover the LDAs objects from the model.
        lda_mod_SB = self.profiled_model["lda_obj_SB"]   

        # Create the factor graph that will be used. 
        #graph = scalib.attacks.FactorGraph(sasca_utils.SASCA_GRAPH_D2_Y, {"sbox":sasca_utils.SBOX}) 
        graph = scalib.attacks.FactorGraph(GRAPH)

        # Amount of traces to keep track of the amount of traces used during the attack.       
        cnt_traces = 0
        iterobj = attack_dataset.iter_ntraces(None, max_chunk_size=MAX_CHUNK_SIZE)

        # Amount of traces to be processed
        nchunks = len(iterobj)

        # Allocate memory to store the likelihood of obtain for each
        # byte of the key and for each chunks.
        like = np.zeros([nchunks,16,256])

        for cidx,chunk in tqdm.tqdm(enumerate(iterobj),total=len(iterobj)):
            # Update counter 
            cnt_traces += chunk['traces'].shape[0]

            # Counter traces if required. 
            if not(centered):
                utraces = chunk["traces"]
            else:
                utraces = np.round(chunk["traces"] - np.mean(chunk['traces'],axis=1,keepdims=True)).astype(np.int16)

            # Recover the probability given the leakages values  
            probas_SB = list(lda_mod_SB.predict_proba(utraces))
            probas_SB = np.pad(probas_SB, ((0, 0), (0, 0), (0, 254))) 
            print(np.array(probas_SB).shape)
            # Fetch amount of traces in the chunk
            ntraces = chunk['traces'].shape[0]
    
            # Create the graphs
            graphs = [scalib.attacks.BPState(graph,ntraces,{"P":chunk["umsk_plaintext"][:,bidx].astype(np.uint32)}) for bidx in range(16)]

            # Set the distributions for each graph
            c = 0
            for name in NAMES:
                for shi in range(2):
                    for bidx in range(16):
                    # Get tap signal ID use for profiling of the share
                        graphs[bidx].set_evidence(f"{name}_{shi}",probas_SB[self.map_in2out_SB[bidx] * 2 + shi + c * 32])
                c += 1

            # Execute the belief propagation computation. 
            print("Run BP...")
            nthread = 16
            if nthread==1:
                ## Single thread run
                for g in graphs:
                    g.bp_loopy(1, True)
            else:
                ## Multi thread run
                mpf = lambda g: g.bp_loopy(5, True)
                with scalib.tools.ContextExecutor(max_workers=nthread) as e:
                    results = list(e.map(mpf,graphs)) 

            # Recover the probabilities of the key bytes. 
            for gi, g in enumerate(graphs):
                like[cidx,gi,:] = g.get_distribution("K")

            # log_like = np.log2(like[:cidx+1])
            # sum_log_like = np.sum(log_like, axis=0)
            # kg = KeyGuess(
            #        [list(range(8 * i, 8 * (i + 1))) for i in range(16)],
            #        (-sum_log_like).tolist()
            #    )
            # ub = eval_utils.eval_attack(kg, '/home//work/Projects/SMAesH-challenge/smaesh-dataset/A7_d2/fk0/manifest_split.json')
            # ## If you apply modification (see Beyond Python section), the following print must remain.
            #
            # tqdm.tqdm.write("Amount of traces used in attack: {}".format(cnt_traces))
            # tqdm.tqdm.write(f'log2 rank {np.log2(ub)}')
            # tqdm.tqdm.write(f'success {ub < eval_utils.MAX_SUCCESS_RANK}\n')


        # Print some stats about the attack. 
        print("Amount of traces used in attack: {}".format(cnt_traces))

        ## Recombine the sub-results obtained for each chunks.
        # Instead of multiplying probabilities together, we sum the log-probas values obtained
        # to avoid numerical issues. 
        log_like = np.log2(like)
        sum_log_like = np.sum(log_like,axis=0) 

        # Create key guess object. Here, we give probabilities for each pf the
        # 16-bytes of the unmasked-key. See key_guess.py for more info.  
        kg = KeyGuess(
                [list(range(8*i,8*(i+1))) for i in range(16)],
                (-sum_log_like).tolist()
                )

        # As required, return the KeyGuess object
        return kg 

